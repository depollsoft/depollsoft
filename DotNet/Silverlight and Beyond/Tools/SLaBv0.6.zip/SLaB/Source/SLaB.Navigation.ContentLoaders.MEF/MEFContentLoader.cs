﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using SLaB.Navigation.ContentLoaders.Utilities;

namespace SLaB.Navigation.ContentLoaders.MEF
{
    /// <summary>
    /// ContentLoader that uses MEF to locate Pages for the given Uris.
    /// </summary>
    public class MEFContentLoader : ContentLoaderBase
    {
        /// <summary>
        /// Creates the LoaderBase for the MEFContentLoader.
        /// </summary>
        /// <returns></returns>
        protected override LoaderBase CreateLoader()
        {
            return new Loader(this);
        }

        /// <summary>
        /// Gets or sets the CompositionContainer to use when loading.  If Container is null,
        /// CompositionInitializer will be used.
        /// </summary>
        public CompositionContainer Container
        {
            get { return (CompositionContainer)GetValue(ContainerProperty); }
            set { SetValue(ContainerProperty, value); }
        }

        /// <summary>
        /// Gets or sets the CompositionContainer to use when loading.  If Container is null,
        /// CompositionInitializer will be used.
        /// </summary>
        public static readonly DependencyProperty ContainerProperty =
            DependencyProperty.Register("Container", typeof(CompositionContainer), typeof(MEFContentLoader), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the ExportFactories that are used to fulfill requests to load.
        /// </summary>
        [ImportMany(AllowRecomposition = true)]
        public IEnumerable<ExportFactory<Page, IExportPageMetadata>> PageFactories { get; set; }

        private bool initialized;
        private void Initialize()
        {
            if (Container == null)
                CompositionInitializer.SatisfyImports(this);
            else
                Container.ComposeParts(this);
            initialized = true;
        }

        private class Loader : LoaderBase
        {
            private MEFContentLoader parent;
            public Loader(MEFContentLoader parent)
            {
                this.parent = parent;
            }

            public override void Load(Uri targetUri, Uri currentUri)
            {
                try
                {
                    if (!parent.initialized)
                        parent.Initialize();
                    if (!targetUri.IsAbsoluteUri)
                        targetUri = new Uri("dummy:///" + targetUri.OriginalString);
                    var pageFactory = parent.PageFactories.Single((factory) =>
                        {
                            Uri uri = GetTrimmedUri(factory.Metadata.NavigateUri);
                            if (!uri.IsAbsoluteUri)
                                uri = new Uri("dummy:///" + uri.OriginalString);
                            return targetUri.Equals(uri);
                        });
                    var pageContext = pageFactory.CreateExport();
                    Complete(pageContext.Value);
                }
                catch(Exception e)
                {
                    Error(e);
                }
            }

            private static Uri GetTrimmedUri(string uriString)
            {
                if (uriString.Contains('?'))
                    uriString = uriString.Substring(0, uriString.IndexOf('?') + 1);
                Uri result;
                try
                {
                    result = new Uri(uriString, UriKind.Absolute);
                }
                catch
                {
                    result = new Uri(uriString, UriKind.Relative);
                }
                return result;
            }

            public override void Cancel()
            {
            }
        }
    }
}
