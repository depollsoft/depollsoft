﻿using System.Windows.Controls;
using System.Windows.Navigation;

namespace TernaryXap
{
    public partial class AwesomePage : Page
    {
        public AwesomePage()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

    }
}
