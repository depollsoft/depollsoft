﻿using System.Windows.Controls;
using System.Windows.Navigation;

namespace NavigationTests
{
    public partial class ExistingPage : Page
    {
        public ExistingPage()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

    }
}
