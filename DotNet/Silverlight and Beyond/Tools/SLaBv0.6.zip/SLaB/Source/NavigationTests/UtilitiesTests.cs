﻿using System;
using System.Threading;
using System.Windows.Controls;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SLaB.Navigation.ContentLoaders.Utilities;
using SLaB.Navigation.Utilities;

namespace NavigationTests
{
    [TestClass]
    public class UtilitiesTests : SilverlightTest
    {
        private TestContentLoader redirectingContentLoader;
        private TestContentLoader pageReturningContentLoader;
        private Uri currentUri;
        private Uri targetUri;

        [TestInitialize]
        public void SetupTests()
        {
            pageReturningContentLoader = new TestContentLoader(true);
            redirectingContentLoader = new TestContentLoader(false);
            currentUri = new Uri("current", UriKind.Relative);
            targetUri = new Uri("target", UriKind.Relative);
        }

        [TestMethod]
        public void TestBeginLoad()
        {
            pageReturningContentLoader.BeginLoad(targetUri, currentUri, (result) => { }, null);
            Assert.AreEqual(targetUri, pageReturningContentLoader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, pageReturningContentLoader.LastLoader.CurrentUri);
        }
        [TestMethod]
        public void TestRedirectBeginLoad()
        {
            redirectingContentLoader.BeginLoad(targetUri, currentUri, (result) => { }, null);
            Assert.AreEqual(targetUri, redirectingContentLoader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, redirectingContentLoader.LastLoader.CurrentUri);
        }
        [TestMethod]
        [Asynchronous]
        public void TestLoad()
        {
            TestContentLoader loader = pageReturningContentLoader;
            IAsyncResult res = null;
            res = loader.BeginLoad(targetUri, currentUri, (result) =>
            {
                Assert.AreSame(res, result);
                var loadResult = loader.EndLoad(result);
                Assert.IsInstanceOfType(loadResult.LoadedContent, typeof(Page));
                Assert.AreEqual((loadResult.LoadedContent as Page).Tag, targetUri);
                this.TestComplete();
            }, null);
            Assert.IsFalse(!res.CompletedSynchronously && res.IsCompleted);
            Assert.AreEqual(targetUri, loader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, loader.LastLoader.CurrentUri);
        }
        [TestMethod]
        [Asynchronous]
        public void TestLoadRedirect()
        {
            TestContentLoader loader = redirectingContentLoader;
            IAsyncResult res = null;
            res = loader.BeginLoad(targetUri, currentUri, (result) =>
            {
                Assert.AreSame(res, result);
                var loadResult = loader.EndLoad(result);
                Assert.IsNull(loadResult.LoadedContent);
                Assert.AreEqual(loadResult.RedirectUri, new Uri("redirect", UriKind.Relative));
                this.TestComplete();
            }, null);
            Assert.IsFalse(!res.CompletedSynchronously && res.IsCompleted);
            Assert.AreEqual(targetUri, loader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, loader.LastLoader.CurrentUri);
        }
        [TestMethod]
        [Asynchronous]
        public void TestCancel()
        {
            TestContentLoader loader = redirectingContentLoader;
            IAsyncResult res = null;
            EnqueueCallback(() =>
                {
                    res = loader.BeginLoad(targetUri, currentUri, (result) =>
                    {
                        Assert.Fail("Callback should never be called when cancelled");
                    }, null);
                    Assert.IsFalse(!res.CompletedSynchronously && res.IsCompleted);
                },
                () =>
                {
                    loader.CancelLoad(res);
                });
            EnqueueDelay(100);
            EnqueueTestComplete();
        }

        [TestMethod]
        public void TestUriMapping()
        {
            UriMapping mapping = new UriMapping()
            {
                Uri = new Uri("/{path1}/{path2}", UriKind.Relative),
                MappedUri = new Uri("/SomeStuff/{path1}/{path1}/{path2}", UriKind.Relative)
            };
            var result = mapping.MapUri(new Uri("/Test1-Test2/Test3-Test4", UriKind.Relative));
            Assert.AreEqual("/SomeStuff/Test1-Test2/Test1-Test2/Test3-Test4", result.OriginalString);
            result = mapping.MapUri(new Uri("/Test1-Test2", UriKind.Relative));
            Assert.IsNull(result);
        }

        [TestMethod]
        public void TestUriMapper()
        {
            UriMapping mapping1 = new UriMapping()
            {
                Uri = new Uri("/{path1}/{path2}", UriKind.Relative),
                MappedUri = new Uri("/SomeStuff/{path1}/{path1}/{path2}", UriKind.Relative)
            };
            UriMapping mapping2 = new UriMapping()
            {
                Uri = new Uri("/{path1}", UriKind.Relative),
                MappedUri = new Uri("/SomeStuff/{path1}/{path1}", UriKind.Relative)
            };
            UriMapper mapper = new UriMapper();
            mapper.UriMappings.Add(mapping1);
            mapper.UriMappings.Add(mapping2);
            var result = mapper.MapUri(new Uri("/Foo/Bar", UriKind.Relative));
            Assert.AreEqual("/SomeStuff/Foo/Foo/Bar", result.OriginalString);
            result = mapper.MapUri(new Uri("/Foo", UriKind.Relative));
            Assert.AreEqual("/SomeStuff/Foo/Foo", result.OriginalString);
            result = mapper.MapUri(new Uri("Foo", UriKind.Relative));
            Assert.AreEqual("Foo", result.OriginalString);
        }
    }

    class TestLoader : LoaderBase
    {
        private bool returnsPage;
        public TestLoader(bool returnsPage)
        {
            this.returnsPage = returnsPage;
        }
        public override void Load(Uri targetUri, Uri currentUri)
        {
            TargetUri = targetUri;
            CurrentUri = currentUri;
            ThreadPool.QueueUserWorkItem((obj) =>
            {
                Thread.Sleep(100);
                if (returnsPage)
                    Complete(() => new Page() { Tag = targetUri });
                else
                    Complete(new Uri("redirect", UriKind.Relative));
            });
        }

        public override void Cancel()
        {
            Cancelled = true;
        }

        public Uri TargetUri { get; private set; }
        public Uri CurrentUri { get; private set; }
        public bool Cancelled { get; private set; }
    }

    class TestContentLoader : ContentLoaderBase
    {
        private bool returnsPage;
        public TestContentLoader(bool returnsPage)
        {
            this.returnsPage = returnsPage;
        }
        public TestLoader LastLoader { get; private set; }
        protected override LoaderBase CreateLoader()
        {
            LastLoader = new TestLoader(returnsPage);
            return LastLoader;
        }
    }
}
