﻿using System.Windows;

namespace SLaB.Utilities.Xap
{
    /// <summary>
    /// Provides application part and localization information in the application manifest when deploying a Silverlight-based application.
    /// </summary>
    public class Manifest : DependencyObject
    {
        /// <summary>
        /// Constructs a manifest.
        /// </summary>
        public Manifest()
        {
            ExternalParts = new ExternalPartCollection();
            Parts = new AssemblyPartCollection();
        }

        /// <summary>
        /// Gets or sets a string name that identifies which part in the System.Windows.Deployment is the entry point assembly.
        /// </summary>
        public string EntryPointAssembly
        {
            get { return (string)GetValue(EntryPointAssemblyProperty); }
            set { SetValue(EntryPointAssemblyProperty, value); }
        }

        /// <summary>
        /// Gets or sets a string name that identifies which part in the System.Windows.Deployment is the entry point assembly.
        /// </summary>
        public static readonly DependencyProperty EntryPointAssemblyProperty =
            DependencyProperty.Register("EntryPointAssembly", typeof(string), typeof(Manifest), new PropertyMetadata(""));

        /// <summary>
        /// Gets or sets a string that identifies the namespace and type name of the class that contains the System.Windows.Application entry point for your application.
        /// </summary>
        public string EntryPointType
        {
            get { return (string)GetValue(EntryPointTypeProperty); }
            set { SetValue(EntryPointTypeProperty, value); }
        }

        /// <summary>
        /// Gets or sets a string that identifies the namespace and type name of the class that contains the System.Windows.Application entry point for your application.
        /// </summary>
        public static readonly DependencyProperty EntryPointTypeProperty =
            DependencyProperty.Register("EntryPointType", typeof(string), typeof(Manifest), new PropertyMetadata(""));

        /// <summary>
        /// Gets or sets a value that indicates the level of access that cross-domain callers have to the Silverlight-based application in this deployment.
        /// </summary>
        public CrossDomainAccess ExternalCallersFromCrossDomain
        {
            get { return (CrossDomainAccess)GetValue(ExternalCallersFromCrossDomainProperty); }
            set { SetValue(ExternalCallersFromCrossDomainProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value that indicates the level of access that cross-domain callers have to the Silverlight-based application in this deployment.
        /// </summary>
        public static readonly DependencyProperty ExternalCallersFromCrossDomainProperty =
            DependencyProperty.Register("ExternalCallersFromCrossDomain", typeof(CrossDomainAccess), typeof(Manifest), new PropertyMetadata(CrossDomainAccess.NoAccess));

        /// <summary>
        /// Gets or sets a collection of System.Windows.ExternalPart instances that represent the external assemblies required by the application.
        /// </summary>
        public ExternalPartCollection ExternalParts
        {
            get { return (ExternalPartCollection)GetValue(ExternalPartsProperty); }
            set { SetValue(ExternalPartsProperty, value); }
        }

        /// <summary>
        /// Gets or sets a collection of System.Windows.ExternalPart instances that represent the external assemblies required by the application.
        /// </summary>
        public static readonly DependencyProperty ExternalPartsProperty =
            DependencyProperty.Register("ExternalParts", typeof(ExternalPartCollection), typeof(Manifest), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets an object that contains information about the application that is used for out-of-browser support.
        /// </summary>
        public OutOfBrowserSettings OutOfBrowserSettings
        {
            get { return (OutOfBrowserSettings)GetValue(OutOfBrowserSettingsProperty); }
            set { SetValue(OutOfBrowserSettingsProperty, value); }
        }

        /// <summary>
        /// Gets or sets an object that contains information about the application that is used for out-of-browser support.
        /// </summary>
        public static readonly DependencyProperty OutOfBrowserSettingsProperty =
            DependencyProperty.Register("OutOfBrowserSettings", typeof(OutOfBrowserSettings), typeof(Manifest), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets a collection of assembly parts that are included in the deployment.
        /// </summary>
        public AssemblyPartCollection Parts
        {
            get { return (AssemblyPartCollection)GetValue(PartsProperty); }
            set { SetValue(PartsProperty, value); }
        }

        /// <summary>
        /// Gets or sets a collection of assembly parts that are included in the deployment.
        /// </summary>
        public static readonly DependencyProperty PartsProperty =
            DependencyProperty.Register("Parts", typeof(AssemblyPartCollection), typeof(Manifest), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the Silverlight runtime version that this deployment supports.
        /// </summary>
        public string RuntimeVersion
        {
            get { return (string)GetValue(RuntimeVersionProperty); }
            set { SetValue(RuntimeVersionProperty, value); }
        }

        /// <summary>
        /// Gets or sets the Silverlight runtime version that this deployment supports.
        /// </summary>
        public static readonly DependencyProperty RuntimeVersionProperty =
            DependencyProperty.Register("RuntimeVersion", typeof(string), typeof(Manifest), new PropertyMetadata(""));
    }
}
