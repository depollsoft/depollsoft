﻿using System;
using System.Security.Principal;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Navigation;
using SLaB.Navigation.ContentLoaders.Utilities;

namespace SLaB.Navigation.ContentLoaders.Auth
{
    /// <summary>
    /// An INavigationContentLoader that throws an UnauthorizedAccessException if the user does not meet the requirements
    /// specified for the page they are trying to navigate to.
    /// </summary>
    [ContentProperty("Authorizer")]
    public class AuthContentLoader : ContentLoaderBase
    {
        private static INavigationContentLoader defaultLoader = new PageResourceContentLoader();

        /// <summary>
        /// The INavigationContentLoader being wrapped by the AuthContentLoader.
        /// </summary>
        public INavigationContentLoader ContentLoader
        {
            get { return (INavigationContentLoader)GetValue(ContentLoaderProperty); }
            set { SetValue(ContentLoaderProperty, value); }
        }

        /// <summary>
        /// The INavigationContentLoader being wrapped by the AuthContentLoader.
        /// </summary>
        public static readonly DependencyProperty ContentLoaderProperty =
            DependencyProperty.Register("ContentLoader", typeof(INavigationContentLoader), typeof(AuthContentLoader), new PropertyMetadata(null));


        /// <summary>
        /// The principal that will be used to check authorization.  Bind this to, for example, the 
        /// </summary>
        public IPrincipal Principal
        {
            get { return (IPrincipal)GetValue(PrincipalProperty); }
            set { SetValue(PrincipalProperty, value); }
        }

        /// <summary>
        /// The principal that will be used to check authorization.
        /// </summary>
        public static readonly DependencyProperty PrincipalProperty =
            DependencyProperty.Register("Principal", typeof(IPrincipal), typeof(AuthContentLoader), new PropertyMetadata(null));


        /// <summary>
        /// The Authorizer that will be used to authorize the Principal.
        /// </summary>
        public INavigationAuthorizer Authorizer
        {
            get { return (INavigationAuthorizer)GetValue(AuthorizerProperty); }
            set { SetValue(AuthorizerProperty, value); }
        }

        /// <summary>
        /// The Authorizer that will be used to authorize the Principal.
        /// </summary>
        public static readonly DependencyProperty AuthorizerProperty =
            DependencyProperty.Register("Authorizer", typeof(INavigationAuthorizer), typeof(AuthContentLoader), new PropertyMetadata(null));

        /// <summary>
        /// Gets a value that indicates whether the specified URI can be loaded.
        /// </summary>
        /// <param name="targetUri">The URI to test.</param>
        /// <param name="currentUri">The URI that is currently loaded.</param>
        /// <returns>true if the URI can be loaded; otherwise, false.</returns>
        public override bool CanLoad(Uri targetUri, Uri currentUri)
        {
            return (ContentLoader ?? defaultLoader).CanLoad(targetUri, currentUri);
        }

        /// <summary>
        /// Creates an instance of a LoaderBase that will be used to handle loading.
        /// </summary>
        /// <returns>An instance of a LoaderBase.</returns>
        protected override LoaderBase CreateLoader()
        {
            return new AuthLoader(this);
        }

        private class AuthLoader : LoaderBase
        {
            private INavigationContentLoader loader;
            private AuthContentLoader parent;
            private IAsyncResult result;
            public AuthLoader(AuthContentLoader parent)
            {
                this.parent = parent;
            }
            public override void Load(Uri targetUri, Uri currentUri)
            {
                loader = parent.ContentLoader ?? defaultLoader;
                if (parent.Authorizer != null)
                {
                    try
                    {
                        parent.Authorizer.CheckAuthorization(parent.Principal, targetUri, currentUri);
                    }
                    catch (Exception e)
                    {
                        Error(e);
                        return;
                    }
                }
                try
                {
                    result = loader.BeginLoad(targetUri, currentUri, (res) =>
                        {
                            try
                            {
                                var loadResult = loader.EndLoad(res);
                                if (loadResult.RedirectUri != null)
                                    Complete(loadResult.RedirectUri);
                                else
                                    Complete(loadResult.LoadedContent);
                                return;
                            }
                            catch (Exception e)
                            {
                                Error(e);
                                return;
                            }
                        }, null);
                }
                catch (Exception e)
                {
                    Error(e);
                    return;
                }
            }

            public override void Cancel()
            {
                loader.CancelLoad(result);
            }
        }

    }
}
