﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using SLaB.Navigation.Controls.Sitemap;
using SLaB.Utilities;
using SLaB.Utilities.ChangeLinq;

namespace SLaB.Navigation.Controls
{
    /// <summary>
    /// An abstract base class for controls that represent a Sitemap.
    /// </summary>
    [ContentProperty("Sitemap")]
    public abstract class Navigator : Control
    {
        private Dictionary<ISitemapNode, SitemapNodeProxy> proxies;
        /// <summary>
        /// Creates a Navigator.
        /// </summary>
        public Navigator()
        {
            proxies = new Dictionary<ISitemapNode, SitemapNodeProxy>();
            this.Unloaded += new RoutedEventHandler(Navigator_Unloaded);
            this.Loaded += new RoutedEventHandler(Navigator_Loaded);
        }

        private void Navigator_Loaded(object sender, RoutedEventArgs e)
        {
            OnSitemapChangedInternal();
        }

        private void Navigator_Unloaded(object sender, RoutedEventArgs e)
        {
            this.Cleanup();
        }

        /// <summary>
        /// Removes proxies and clears the TrimmedSitemap.
        /// </summary>
        protected virtual void Cleanup()
        {
            proxies.Clear();
            TrimmedSitemap = null;
        }

        internal SitemapNodeProxy GetProxy(ISitemapNode node)
        {
            if (proxies.ContainsKey(node))
                return proxies[node];
            proxies[node] = new SitemapNodeProxy(IsNodeVisible, GetProxy);
            proxies[node].Host = this;
            proxies[node].Node = node;
            return proxies[node];
        }

        private void OnSitemapChangedInternal()
        {
            if (Sitemap == null)
                TrimmedSitemap = null;
            else
                TrimmedSitemap = from node in Sitemap.Nodes.AsChangeLinq()
                                 where IsNodeVisible(node)
                                 select GetProxy(node);
            OnSitemapChanged();
        }

        /// <summary>
        /// Called when the Sitemap property is changed.
        /// </summary>
        protected virtual void OnSitemapChanged()
        {
        }

        private bool IsNodeVisible(ISitemapNode node)
        {
            if (!IsSitemapTrimmingEnabled)
                return true;
            return node.IsVisibleTo(Principal);
        }

        private static void OnSitemapChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((Navigator)obj).OnSitemapChangedInternal();
        }

        /// <summary>
        /// Gets or sets a value that determines whether Sitemap trimming based on the Principal is enabled.
        /// </summary>
        public bool IsSitemapTrimmingEnabled
        {
            get { return (bool)GetValue(TrimSitemapProperty); }
            set { SetValue(TrimSitemapProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value that determines whether Sitemap trimming based on the Principal is enabled.
        /// </summary>
        public static readonly DependencyProperty TrimSitemapProperty =
            DependencyProperty.Register("IsSitemapTrimmingEnabled", typeof(bool), typeof(Navigator), new PropertyMetadata(true, OnRefreshingPropertyChanged));

        /// <summary>
        /// Gets or sets the Sitemap being represented by this Navigator.
        /// </summary>
        public Sitemap.ISitemap Sitemap
        {
            get { return (Sitemap.ISitemap)GetValue(SitemapProperty); }
            set { SetValue(SitemapProperty, value); }
        }

        /// <summary>
        /// Gets or sets the Sitemap being represented by this Navigator.
        /// </summary>
        public static readonly DependencyProperty SitemapProperty =
            DependencyProperty.Register("Sitemap", typeof(Sitemap.ISitemap), typeof(Navigator), new PropertyMetadata(null, OnSitemapChanged));

        /// <summary>
        /// Gets the trimmed Sitemap.
        /// </summary>
        public IEnumerable<Sitemap.SitemapNodeProxy> TrimmedSitemap
        {
            get { return (IEnumerable<Sitemap.SitemapNodeProxy>)GetValue(TrimmedSitemapProperty); }
            private set { SetValue(TrimmedSitemapProperty, value); }
        }

        /// <summary>
        /// Gets the trimmed Sitemap.
        /// </summary>
        private static readonly DependencyProperty TrimmedSitemapProperty =
            DependencyProperty.Register("TrimmedSitemap", typeof(IEnumerable<Sitemap.SitemapNodeProxy>), typeof(Navigator), new PropertyMetadata(null, OnTrimmedSitemapChanged));

        private static void OnTrimmedSitemapChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((Navigator)obj).OnTrimmedSitemapChangedInternal();
        }

        private void OnTrimmedSitemapChangedInternal()
        {
            OnTrimmedSitemapChanged();
        }

        /// <summary>
        /// Called when the TrimmedSitemap changes.
        /// </summary>
        protected virtual void OnTrimmedSitemapChanged()
        {
        }

        private void Refresh()
        {
            if (TrimmedSitemap != null)
            {
                ((IRefreshable)TrimmedSitemap).Refresh();
                foreach (var proxy in TrimmedSitemap)
                    proxy.Refresh();
                OnTrimmedSitemapChangedInternal();
            }
        }

        private static void OnRefreshingPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((Navigator)obj).Refresh();
        }

        /// <summary>
        /// Gets or sets the Principal used for Sitemap trimming.
        /// </summary>
        public IPrincipal Principal
        {
            get { return (IPrincipal)GetValue(PrincipalProperty); }
            set { SetValue(PrincipalProperty, value); }
        }

        /// <summary>
        /// Gets or sets the Principal used for Sitemap trimming.
        /// </summary>
        public static readonly DependencyProperty PrincipalProperty =
            DependencyProperty.Register("Principal", typeof(IPrincipal), typeof(Navigator), new PropertyMetadata(null, OnRefreshingPropertyChanged));

        /// <summary>
        /// Gets or sets the CurrentSource for this Navigator.  This is usually bound to the CurrentSource property of a Frame control.
        /// </summary>
        public Uri CurrentSource
        {
            get { return (Uri)GetValue(CurrentSourceProperty); }
            set { SetValue(CurrentSourceProperty, value); }
        }

        /// <summary>
        /// Gets or sets the CurrentSource for this Navigator.  This is usually bound to the CurrentSource property of a Frame control.
        /// </summary>
        public static readonly DependencyProperty CurrentSourceProperty =
            DependencyProperty.Register("CurrentSource", typeof(Uri), typeof(Navigator), new PropertyMetadata(null, OnCurrentSourceChanged));

        private bool RefreshCurrency(SitemapNodeProxy proxy)
        {
            bool isInPath = false;
            bool isCurrentSource = false;
            foreach (var child in proxy.Nodes)
                isInPath = RefreshCurrency(child) || isInPath;
            if (UriUtilities.Equals(CurrentSource, proxy.Node.Uri))
            {
                isCurrentSource = true;
                CurrentNode = proxy;
            }
            proxy.IsCurrentSource = isCurrentSource;
            proxy.IsChildCurrentSource = isInPath;
            proxy.IsInPath = isCurrentSource || isInPath;
            return isCurrentSource || isInPath;
        }

        /// <summary>
        /// Gets the SitemapNodeProxy for the currently selected Node (i.e. the Node that represents the CurrentSource).
        /// </summary>
        protected SitemapNodeProxy CurrentNode
        {
            get;
            private set;
        }

        private void OnCurrentSourceChangedInternal()
        {
            if (Sitemap == null)
                return;
            foreach (var proxy in TrimmedSitemap)
                RefreshCurrency(proxy);
            OnCurrentSourceChanged();
        }

        /// <summary>
        /// Called when CurrentSource changes.
        /// </summary>
        protected virtual void OnCurrentSourceChanged()
        {
        }

        private static void OnCurrentSourceChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((Navigator)obj).OnCurrentSourceChangedInternal();
        }

        /// <summary>
        /// Gets or sets the template for displaying the Sitemap header (usually used to display the Sitemap's title and description).
        /// </summary>
        public DataTemplate SitemapHeaderTemplate
        {
            get { return (DataTemplate)GetValue(SitemapHeaderTemplateProperty); }
            set { SetValue(SitemapHeaderTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template for displaying the Sitemap header (usually used to display the Sitemap's title and description).
        /// </summary>
        public static readonly DependencyProperty SitemapHeaderTemplateProperty =
            DependencyProperty.Register("SitemapHeaderTemplate", typeof(DataTemplate), typeof(Navigator), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the visibility of the Sitemap header.
        /// </summary>
        public Visibility SitemapHeaderVisibility
        {
            get { return (Visibility)GetValue(SitemapHeaderVisibilityProperty); }
            set { SetValue(SitemapHeaderVisibilityProperty, value); }
        }

        /// <summary>
        /// Gets or sets the visibility of the Sitemap header.
        /// </summary>
        public static readonly DependencyProperty SitemapHeaderVisibilityProperty =
            DependencyProperty.Register("SitemapHeaderVisibility", typeof(Visibility), typeof(Navigator), new PropertyMetadata(Visibility.Collapsed));

        /// <summary>
        /// Gets or sets the template that is used to display each node in the Sitemap.  Its DataContext is a SitemapNodeProxy.
        /// </summary>
        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template that is used to display each node in the Sitemap.  Its DataContext is a SitemapNodeProxy.
        /// </summary>
        public static readonly DependencyProperty ItemTemplateProperty =
            DependencyProperty.Register("ItemTemplate", typeof(DataTemplate), typeof(Navigator), new PropertyMetadata(null));
    }
}
