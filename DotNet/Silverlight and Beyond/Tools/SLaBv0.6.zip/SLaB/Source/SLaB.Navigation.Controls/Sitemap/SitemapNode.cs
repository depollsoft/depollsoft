﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Security.Principal;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;
using SLaB.Utilities;


namespace SLaB.Navigation.Controls.Sitemap
{
    /// <summary>
    /// Represents a node within a Sitemap.
    /// </summary>
    [ContentProperty("Nodes")]
    public class SitemapNode : DependencyObject, ISitemapNode
    {
        /// <summary>
        /// Creates a new SitemapNode.
        /// </summary>
        public SitemapNode()
        {
            Nodes = new DependencyObjectCollection<ISitemapNode>();
            Nodes.CollectionChanged += Nodes_CollectionChanged;
            BindingOperations.SetBinding(this, TitleProperty, new Binding("Uri") { Source = this });
        }

        /// <summary>
        /// Determines whether this SitemapNode should be trimmed for the given principal.
        /// </summary>
        /// <param name="principal">The principal whose access should be tested.</param>
        /// <returns>true if the principal should see this node and its children.  false otherwise.</returns>
        public virtual bool IsVisibleTo(IPrincipal principal)
        {
            var result = (from r in (string.IsNullOrWhiteSpace(Roles) ? "*" : Roles).Split(',')
                          let role = r.Trim()
                          select role.Equals("*") || (principal != null && principal.IsInRole(role))).Any((b) => b);
            return result;
        }

        /// <summary>
        /// Gets whether this SitemapNode supports being navigated to.
        /// </summary>
        public bool IsNavigable
        {
            get { return (bool)GetValue(IsNavigableProperty); }
            private set { SetValue(IsNavigableProperty, value); }
        }

        /// <summary>
        /// Gets whether this SitemapNode supports being navigated to.
        /// </summary>
        public static readonly DependencyProperty IsNavigableProperty =
            DependencyProperty.Register("IsNavigable", typeof(bool), typeof(SitemapNode), new PropertyMetadata(false));

        

        private void Nodes_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Reset)
            {
                if (!DesignerProperties.IsInDesignTool)
                    throw new Exception("Cannot Reset the Nodes collection");
            }
            else
            {
                if (e.NewItems != null)
                    foreach (ISitemapNode node in e.NewItems)
                        node.NodeChanged += node_NodeChanged;
                if (e.OldItems != null)
                    foreach (ISitemapNode node in e.OldItems)
                        node.NodeChanged -= node_NodeChanged;
            }
        }

        private void node_NodeChanged(object sender, EventArgs e)
        {
            RaiseNodeChanged();
        }

        /// <summary>
        /// An event that is raised whenever this node or its children has changed.
        /// </summary>
        public event EventHandler<EventArgs> NodeChanged;

        /// <summary>
        /// Gets list of child nodes for this SitemapNode.
        /// </summary>
        public DependencyObjectCollection<ISitemapNode> Nodes
        {
            get { return (DependencyObjectCollection<ISitemapNode>)GetValue(NodesProperty); }
            protected set { SetValue(NodesProperty, value); }
        }

        /// <summary>
        /// Gets list of child nodes for this SitemapNode.
        /// </summary>
        private static readonly DependencyProperty NodesProperty =
            DependencyProperty.Register("Nodes", typeof(DependencyObjectCollection<ISitemapNode>), typeof(SitemapNode), new PropertyMetadata(null, OnPropertyChanged));

        IEnumerable<ISitemapNode> ISitemapNode.Nodes
        {
            get
            {
                return this.Nodes;
            }
        }

        /// <summary>
        /// Gets or sets the description for this SitemapNode.
        /// </summary>
        public string Description
        {
            get { return (string)GetValue(DescriptionProperty); }
            set { SetValue(DescriptionProperty, value); }
        }

        /// <summary>
        /// Gets or sets the description for this SitemapNode.
        /// </summary>
        public static readonly DependencyProperty DescriptionProperty =
            DependencyProperty.Register("Description", typeof(string), typeof(SitemapNode), new PropertyMetadata(null, OnPropertyChanged));

        /// <summary>
        /// Gets or sets the title for this SitemapNode.
        /// </summary>
        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the title for this SitemapNode.
        /// </summary>
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(SitemapNode), new PropertyMetadata("", OnPropertyChanged));


        /// <summary>
        /// Gets or sets the Uri for this SitemapNode.
        /// </summary>
        public Uri Uri
        {
            get { return (Uri)GetValue(UriProperty); }
            set { SetValue(UriProperty, value); }
        }

        /// <summary>
        /// Gets or sets the Uri for this SitemapNode.
        /// </summary>
        public static readonly DependencyProperty UriProperty =
            DependencyProperty.Register("Uri", typeof(Uri), typeof(SitemapNode), new PropertyMetadata(null, OnPropertyChanged));

        /// <summary>
        /// Gets or sets the target for this SitemapNode (e.g. _blank, _top, or the name of a Frame).
        /// </summary>
        public string TargetName
        {
            get { return (string)GetValue(TargetNameProperty); }
            set { SetValue(TargetNameProperty, value); }
        }

        /// <summary>
        /// Gets or sets the target for this SitemapNode (e.g. _blank, _top, or the name of a Frame).
        /// </summary>
        public static readonly DependencyProperty TargetNameProperty =
            DependencyProperty.Register("TargetName", typeof(string), typeof(SitemapNode), new PropertyMetadata("", OnPropertyChanged));

        /// <summary>
        /// Gets or sets the roles allowed for this SitemapNode.  The roles can be a comma-separated list of Role names.  "*"
        /// indicates that all roles should be able to see this SitemapNode.
        /// </summary>
        public string Roles
        {
            get { return (string)GetValue(RolesProperty); }
            set { SetValue(RolesProperty, value); }
        }

        /// <summary>
        /// Gets or sets the roles allowed for this SitemapNode.  The roles can be a comma-separated list of Role names.  "*"
        /// indicates that all roles should be able to see this SitemapNode.
        /// </summary>
        public static readonly DependencyProperty RolesProperty =
            DependencyProperty.Register("Roles", typeof(string), typeof(SitemapNode), new PropertyMetadata("*", OnPropertyChanged));

        private void OnNodeChangedInternal()
        {
            OnNodeChanged();
            RefreshIsNavigable();
            RaiseNodeChanged();
        }

        /// <summary>
        /// Raises the NodeChanged event.
        /// </summary>
        protected void RaiseNodeChanged()
        {
            NodeChanged.Raise(this, new EventArgs());
        }

        /// <summary>
        /// Refreshes the IsNavigable property.
        /// </summary>
        protected void RefreshIsNavigable()
        {
            IsNavigable = GetIsNavigable();
        }

        /// <summary>
        /// Determines whether the SitemapNode is navigable.
        /// </summary>
        /// <returns></returns>
        protected virtual bool GetIsNavigable()
        {
            return Uri != null;
        }

        /// <summary>
        /// Called when the node is changed.
        /// </summary>
        protected virtual void OnNodeChanged()
        {
        }

        private static void OnPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((SitemapNode)obj).OnNodeChangedInternal();
        }
    }
}
