﻿using System;
using System.Collections.Generic;
using System.Windows;
using SLaB.Utilities;
using SLaB.Utilities.ChangeLinq;

namespace SLaB.Navigation.Controls.Sitemap
{
    /// <summary>
    /// A Proxy for a SitemapNode that adds metadata for tracking whether the node is in the current path,
    /// the host for the node, etc.
    /// </summary>
    public class SitemapNodeProxy : DependencyObject, IRefreshable
    {
        private Func<ISitemapNode, SitemapNodeProxy> proxyCreator;
        internal SitemapNodeProxy(Predicate<ISitemapNode> filter, Func<ISitemapNode, SitemapNodeProxy> proxyCreator = null)
        {
            this.filter = filter;
            if (proxyCreator == null)
                this.proxyCreator = (node) => new SitemapNodeProxy(this.filter, this.proxyCreator) { Node = node, Host = this.Host };
            else
                this.proxyCreator = proxyCreator;
        }

        /// <summary>
        /// Gets the Host for the SitemapNode (e.g. TreeViewNavigator or BreadCrumbNavigator).
        /// </summary>
        public DependencyObject Host
        {
            get { return (DependencyObject)GetValue(HostProperty); }
            internal set { SetValue(HostProperty, value); }
        }

        /// <summary>
        /// Gets the Host for the SitemapNode (e.g. TreeViewNavigator or BreadCrumbNavigator).
        /// </summary>
        public static readonly DependencyProperty HostProperty =
            DependencyProperty.Register("Host", typeof(DependencyObject), typeof(SitemapNodeProxy), new PropertyMetadata(null));

        /// <summary>
        /// Gets the ISitemapNode to which this proxy corresponds.
        /// </summary>
        public ISitemapNode Node
        {
            get { return (ISitemapNode)GetValue(NodeProperty); }
            internal set { SetValue(NodeProperty, value); }
        }

        /// <summary>
        /// Gets the ISitemapNode to which this proxy corresponds.
        /// </summary>
        private static readonly DependencyProperty NodeProperty =
            DependencyProperty.Register("Node", typeof(ISitemapNode), typeof(SitemapNodeProxy), new PropertyMetadata(null, OnNodeChanged));

        /// <summary>
        /// Gets the trimmed list of child proxies that correspond to Node.Nodes.
        /// </summary>
        public IEnumerable<SitemapNodeProxy> Nodes
        {
            get { return (IEnumerable<SitemapNodeProxy>)GetValue(NodesProperty); }
            internal set { SetValue(NodesProperty, value); }
        }

        /// <summary>
        /// Gets the trimmed list of child proxies that correspond to Node.Nodes.
        /// </summary>
        public static readonly DependencyProperty NodesProperty =
            DependencyProperty.Register("Nodes", typeof(IEnumerable<SitemapNodeProxy>), typeof(SitemapNodeProxy), new PropertyMetadata(null));

        /// <summary>
        /// Gets a value indicating whether this node represents the current source.
        /// </summary>
        public bool IsCurrentSource
        {
            get { return (bool)GetValue(IsCurrentSourceProperty); }
            internal set { SetValue(IsCurrentSourceProperty, value); }
        }

        /// <summary>
        /// Gets a value indicating whether this node represents the current source.
        /// </summary>
        public static readonly DependencyProperty IsCurrentSourceProperty =
            DependencyProperty.Register("IsCurrentSource", typeof(bool), typeof(SitemapNodeProxy), new PropertyMetadata(false));

        /// <summary>
        /// Gets a value indicating whether this node is in the current path.
        /// </summary>
        public bool IsInPath
        {
            get { return (bool)GetValue(IsInPathProperty); }
            set { SetValue(IsInPathProperty, value); }
        }

        /// <summary>
        /// Gets a value indicating whether this node is in the current path.
        /// </summary>
        public static readonly DependencyProperty IsInPathProperty =
            DependencyProperty.Register("IsInPath", typeof(bool), typeof(SitemapNodeProxy), new PropertyMetadata(false));

        /// <summary>
        /// Gets a value indicating whether this node is in the current path but is not the current source.
        /// </summary>
        public bool IsChildCurrentSource
        {
            get { return (bool)GetValue(IsChildCurrentSourceProperty); }
            set { SetValue(IsChildCurrentSourceProperty, value); }
        }

        /// <summary>
        /// Gets a value indicating whether this node is in the current path but is not the current source.
        /// </summary>
        public static readonly DependencyProperty IsChildCurrentSourceProperty =
            DependencyProperty.Register("IsChildCurrentSource", typeof(bool), typeof(SitemapNodeProxy), new PropertyMetadata(false));

        private Predicate<ISitemapNode> filter;

        private void OnNodeChanged(DependencyPropertyChangedEventArgs args)
        {
            if (args.OldValue != null)
            {
                ((ISitemapNode)args.OldValue).NodeChanged -= SitemapNodeProxy_NodeChanged;
                if (Nodes is IDisposable)
                {
                    foreach (var proxy in Nodes)
                        proxy.Node = null;
                    ((IDisposable)Nodes).Dispose();
                }
            }
            if (args.NewValue != null)
            {
                ((ISitemapNode)args.NewValue).NodeChanged += SitemapNodeProxy_NodeChanged;
                Nodes = from node in Node.Nodes.AsChangeLinq()
                        where filter(node)
                        select proxyCreator(node);
            }
        }

        private void SitemapNodeProxy_NodeChanged(object sender, EventArgs e)
        {
            Refresh();
        }

        private static void OnNodeChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((SitemapNodeProxy)obj).OnNodeChanged(args);
        }

        /// <summary>
        /// Refreshes the set of Child nodes, ensuring that it matches the list of child nodes for the underlying node.
        /// </summary>
        public void Refresh()
        {
            if (Nodes is IRefreshable)
                ((IRefreshable)Nodes).Refresh();
        }

#if DEBUG
        public override string ToString()
        {
            return string.Format("[Title = {0}, IsInPath = {1}, Nodes = {2}]", Node.Title, IsInPath, ChangeLinq.ToString(Nodes));
        }
#endif
    }
}
