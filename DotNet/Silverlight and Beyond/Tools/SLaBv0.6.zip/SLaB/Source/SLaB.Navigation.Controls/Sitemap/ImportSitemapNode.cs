﻿using System.Windows;

namespace SLaB.Navigation.Controls.Sitemap
{
    /// <summary>
    /// A SitemapNode that imports its data from another Sitemap.
    /// </summary>
    public class ImportSitemapNode : SitemapNode
    {
        private void RefreshFromSource()
        {
            if (SitemapSource.Nodes is DependencyObjectCollection<ISitemapNode>)
                this.Nodes = (DependencyObjectCollection<ISitemapNode>)SitemapSource.Nodes;
            else
            {
                this.Nodes = new DependencyObjectCollection<ISitemapNode>();
                foreach (var node in SitemapSource.Nodes)
                    this.Nodes.Add(node);
            }
            this.Title = SitemapSource.Title;
            this.Description = SitemapSource.Description;
        }

        /// <summary>
        /// The source ISitemap for this SitemapNode.
        /// </summary>
        public ISitemap SitemapSource
        {
            get { return (ISitemap)GetValue(SitemapSourceProperty); }
            set { SetValue(SitemapSourceProperty, value); }
        }

        /// <summary>
        /// The source ISitemap for this SitemapNode.
        /// </summary>
        public static readonly DependencyProperty SitemapSourceProperty =
            DependencyProperty.Register("SitemapSource", typeof(ISitemap), typeof(ImportSitemapNode), new PropertyMetadata(null, OnSitemapSourceChanged));

        private static void OnSitemapSourceChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((ImportSitemapNode)obj).OnSitemapSourceChanged((ISitemap)args.OldValue, (ISitemap)args.NewValue);
        }

        private void OnSitemapSourceChanged(ISitemap oldSitemap, ISitemap newSitemap)
        {
            RefreshFromSource();
        }
    }
}
