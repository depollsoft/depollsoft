﻿using System.ComponentModel;
using System.Text;

namespace SLaB.Utilities.Xaml.Collections
{
    /// <summary>
    /// Represents a KeyValuePair where the value can change (and supports being bound to).
    /// </summary>
    /// <typeparam name="TKey">The type of the key.</typeparam>
    /// <typeparam name="TValue">The type of the value.</typeparam>
    public sealed class ObservableKeyValuePair<TKey, TValue> : INotifyPropertyChanged
    {
        /// <summary>
        /// Creates an ObservableKeyValuePair with the given key.
        /// </summary>
        /// <param name="key">The key for the pair.</param>
        public ObservableKeyValuePair(TKey key)
        {
            this.key = key;
        }
        private TKey key;
        private TValue value;

        /// <summary>
        /// Gets the key for this KeyValuePair.
        /// </summary>
        public TKey Key
        {
            get
            {
                return key;
            }
        }

        /// <summary>
        /// Gets or sets the value for this KeyValuePair.
        /// </summary>
        public TValue Value
        {
            get
            {
                return value;
            }
            set
            {
                if (!object.Equals(this.value, value))
                {
                    this.value = value;
                    OnPropertyChanged("Value");
                }
            }
        }
        private void OnPropertyChanged(string propertyName)
        {
            var pc = PropertyChanged;
            if (pc != null)
                pc(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// An event raised whenever the Value of this ObservableKeyValuePair changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Converts the ObservableKeyValuePair into a string.
        /// </summary>
        /// <returns>A string representation of the ObservableKeyValuePair.</returns>
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append('[');
            if (this.Key != null)
                builder.Append(this.Key.ToString());
            builder.Append(", ");
            if (this.Value != null)
                builder.Append(this.Value.ToString());
            builder.Append(']');
            return builder.ToString();
        }

    }
}
