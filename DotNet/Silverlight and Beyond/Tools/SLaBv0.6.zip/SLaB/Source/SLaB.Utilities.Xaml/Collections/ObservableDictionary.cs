﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;

namespace SLaB.Utilities.Xaml.Collections
{
    /// <summary>
    /// A dictionary that supports INotifyPropertyChanged on its KeyValuePairs and INotifyCollectionChanged on itself, making it friendly for
    /// observation and binding.
    /// </summary>
    /// <typeparam name="TKey">The Key type.</typeparam>
    /// <typeparam name="TValue">The Value type.</typeparam>
    public class ObservableDictionary<TKey, TValue> : INotifyPropertyChanged, INotifyCollectionChanged, IDictionary<TKey, TValue>, ICollection<ObservableKeyValuePair<TKey, TValue>>, IDictionary
    {
        private List<ObservableKeyValuePair<TKey, TValue>> baseCollection;
        private Dictionary<TKey, TValue> baseDictionary;
        private Dictionary<TKey, int> indexDictionary;

        /// <summary>
        /// Gets the equality comparer for the ObservableDictionary.
        /// </summary>
        public IEqualityComparer<TKey> Comparer { get; private set; }

        /// <summary>
        /// Creates an ObservableDictionary.
        /// </summary>
        /// <param name="dictionary">A source dictionary to import KeyValuePairs from.</param>
        /// <param name="comparer">An equality comparer used for comparing and doing lookups.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ObservableDictionary(IDictionary<TKey, TValue> dictionary = null, IEqualityComparer<TKey> comparer = null)
        {
            this.Comparer = comparer;
            baseCollection = new List<ObservableKeyValuePair<TKey, TValue>>();
            baseDictionary = new Dictionary<TKey, TValue>(comparer);
            indexDictionary = new Dictionary<TKey, int>(comparer);
            if (dictionary != null)
                foreach (var pair in dictionary)
                    ((IDictionary<TKey, TValue>)this).Add(pair);
        }

        private void Subscribe(ObservableKeyValuePair<TKey, TValue> item)
        {
            item.PropertyChanged += item_PropertyChanged;
        }

        private void item_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var kvp = (ObservableKeyValuePair<TKey, TValue>)sender;
            baseDictionary[kvp.Key] = kvp.Value;
            OnPropertyChanged("Item[]");
        }

        private void Unsubscribe(ObservableKeyValuePair<TKey, TValue> item)
        {
            item.PropertyChanged -= item_PropertyChanged;
        }

        /// <summary>
        /// Raises the PropertyChanged event.
        /// </summary>
        /// <param name="propertyName">The name of the property that has changed.</param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            var pc = PropertyChanged;
            if (pc != null)
                pc(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Raises the CollectionChanged event.
        /// </summary>
        /// <param name="args">The NotifyCollectionChangedEventArgs to raise the event with.</param>
        protected virtual void OnCollectionChanged(NotifyCollectionChangedEventArgs args)
        {
            var cc = CollectionChanged;
            if (cc != null)
                cc(this, args);
        }

        /// <summary>
        /// An event raised when a property changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// An event raised when the collection changes.
        /// </summary>
        public event NotifyCollectionChangedEventHandler CollectionChanged;

        private void RefreshIndices(int startIndex)
        {
            for (int x = startIndex; x < baseCollection.Count; x++)
                indexDictionary[baseCollection[x].Key] = x;
        }

        /// <summary>
        /// Adds an item to the dictionary.
        /// </summary>
        /// <param name="item">The item to add.</param>
        public void Add(ObservableKeyValuePair<TKey, TValue> item)
        {
            if (baseDictionary.ContainsKey(item.Key))
                throw new ArgumentException("Dictionary already contains key.");
            baseDictionary[item.Key] = item.Value;
            baseCollection.Add(item);
            indexDictionary[item.Key] = baseCollection.Count - 1;
            Subscribe(item);
            OnPropertyChanged("Count");
            OnPropertyChanged("Item[]");
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, item, indexDictionary[item.Key]));
        }

        /// <summary>
        /// Clears the dictionary.
        /// </summary>
        public void Clear()
        {
            foreach (var item in baseCollection)
                Unsubscribe(item);
            baseDictionary.Clear();
            baseCollection.Clear();
            indexDictionary.Clear();
            OnPropertyChanged("Count");
            OnPropertyChanged("Item[]");
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        /// <summary>
        /// Checks to see whether the item is in the dictionary.
        /// </summary>
        /// <param name="item">The item to search for.</param>
        /// <returns>true if the item is in the dictionary.  false otherwise.</returns>
        public bool Contains(ObservableKeyValuePair<TKey, TValue> item)
        {
            return baseCollection.Contains(item);
        }

        /// <summary>
        /// Copies the dictionary into an array.
        /// </summary>
        /// <param name="array">The array to copy into.</param>
        /// <param name="arrayIndex">The index in the array where copying should begin.</param>
        public void CopyTo(ObservableKeyValuePair<TKey, TValue>[] array, int arrayIndex)
        {
            baseCollection.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// Gets the number of items in the dictionary.
        /// </summary>
        public int Count
        {
            get { return baseCollection.Count; }
        }

        /// <summary>
        /// Gets whether the dictionary is read-only.
        /// </summary>
        public bool IsReadOnly
        {
            get { return false; }
        }

        /// <summary>
        /// Removes an item from the dictionary.
        /// </summary>
        /// <param name="item">The item to remove.</param>
        /// <returns>true if the item was removed.  false otherwise.</returns>
        public bool Remove(ObservableKeyValuePair<TKey, TValue> item)
        {
            if (!this.Contains(item))
                return false;
            int index = indexDictionary[item.Key];
            baseCollection.RemoveAt(index);
            for (int x = index; x < baseCollection.Count; x++)
                indexDictionary[baseCollection[x].Key] = x;
            baseDictionary.Remove(item.Key);
            indexDictionary.Remove(item.Key);
            Unsubscribe(item);
            OnPropertyChanged("Count");
            OnPropertyChanged("Item[]");
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, item, index));
            return true;
        }

        /// <summary>
        /// Gets an enumerator over the values in the dictionary.
        /// </summary>
        /// <returns>The enumerator over the ObservableDictionary.</returns>
        public IEnumerator<ObservableKeyValuePair<TKey, TValue>> GetEnumerator()
        {
            return baseCollection.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return ((IEnumerable<ObservableKeyValuePair<TKey, TValue>>)this).GetEnumerator();
        }

        /// <summary>
        /// Adds an item to the dictionary.
        /// </summary>
        /// <param name="key">The key to add.</param>
        /// <param name="value">The value to associate with the key.</param>
        public void Add(TKey key, TValue value)
        {
            this.Add(new ObservableKeyValuePair<TKey, TValue>(key) { Value = value });
        }

        /// <summary>
        /// Checks whether the dictionary contains the given key.
        /// </summary>
        /// <param name="key">The key to search for.</param>
        /// <returns>true if the dictionary contains the given key.  false otherwise.</returns>
        public bool ContainsKey(TKey key)
        {
            return baseDictionary.ContainsKey(key);
        }

        /// <summary>
        /// Gets the set of keys in the dictionary.
        /// </summary>
        public ICollection<TKey> Keys
        {
            get { return baseDictionary.Keys; }
        }

        /// <summary>
        /// Removes an item from the dictionary.
        /// </summary>
        /// <param name="key">The key of the item to remove.</param>
        /// <returns>true if the item was removed.  false otherwise.</returns>
        public bool Remove(TKey key)
        {
            if (!ContainsKey(key))
                return false;
            int index = indexDictionary[key];
            var value = baseCollection[index];
            baseCollection.RemoveAt(index);
            for (int x = index; x < baseCollection.Count; x++)
                indexDictionary[baseCollection[x].Key] = x;
            baseDictionary.Remove(key);
            indexDictionary.Remove(key);
            OnPropertyChanged("Count");
            OnPropertyChanged("Item[]");
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, value, index));
            return true;
        }

        /// <summary>
        /// Attempts to get the value for the given key.
        /// </summary>
        /// <param name="key">The key to look up.</param>
        /// <param name="value">An output parameter set to the value corresponding to the given key.</param>
        /// <returns>true if the value was successfully retrieved.  false otherwise.</returns>
        public bool TryGetValue(TKey key, out TValue value)
        {
            if (!ContainsKey(key))
            {
                value = default(TValue);
                return false;
            }
            value = baseDictionary[key];
            return true;
        }

        /// <summary>
        /// Gets the set of values in the dictionary.
        /// </summary>
        public ICollection<TValue> Values
        {
            get { return baseDictionary.Values; }
        }

        /// <summary>
        /// Gets or sets the value for a given key.
        /// </summary>
        /// <param name="key">The key for the item in the dictionary.</param>
        /// <returns>The value corresponding to the given key.</returns>
        public virtual TValue this[TKey key]
        {
            get
            {
                return baseDictionary[key];
            }
            set
            {
                if (!ContainsKey(key))
                    Add(key, value);
                else
                {
                    baseDictionary[key] = value;
                    baseCollection[indexDictionary[key]].Value = value;
                }
            }
        }

        void ICollection<KeyValuePair<TKey, TValue>>.Add(KeyValuePair<TKey, TValue> item)
        {
            Add(new ObservableKeyValuePair<TKey, TValue>(item.Key) { Value = item.Value });
        }

        bool ICollection<KeyValuePair<TKey, TValue>>.Contains(KeyValuePair<TKey, TValue> item)
        {
            return ((ICollection<KeyValuePair<TKey, TValue>>)baseDictionary).Contains(item);
        }

        void ICollection<KeyValuePair<TKey, TValue>>.CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex)
        {
            ((ICollection<KeyValuePair<TKey, TValue>>)baseDictionary).CopyTo(array, arrayIndex);
        }

        bool ICollection<KeyValuePair<TKey, TValue>>.Remove(KeyValuePair<TKey, TValue> item)
        {
            if (!this.ContainsKey(item.Key))
                return false;
            TValue val = this[item.Key];
            if (!object.Equals(val, item.Value))
                return false;
            return Remove(item.Key);
        }

        IEnumerator<KeyValuePair<TKey, TValue>> IEnumerable<KeyValuePair<TKey, TValue>>.GetEnumerator()
        {
            return baseDictionary.GetEnumerator();
        }

        void IDictionary.Add(object key, object value)
        {
            this.Add((TKey)key, (TValue)value);
        }

        bool IDictionary.Contains(object key)
        {
            return this.ContainsKey((TKey)key);
        }

        IDictionaryEnumerator IDictionary.GetEnumerator()
        {
            return this.baseDictionary.GetEnumerator();
        }

        bool IDictionary.IsFixedSize
        {
            get { return ((IDictionary)this.baseDictionary).IsFixedSize; }
        }

        ICollection IDictionary.Keys
        {
            get { return ((IDictionary)this.baseDictionary).Keys; }
        }

        void IDictionary.Remove(object key)
        {
            this.Remove((TKey)key);
        }

        ICollection IDictionary.Values
        {
            get { return ((IDictionary)this.baseDictionary).Values; }
        }

        object IDictionary.this[object key]
        {
            get
            {
                return this[(TKey)key];
            }
            set
            {
                this[(TKey)key] = (TValue)value;
            }
        }

        void ICollection.CopyTo(Array array, int index)
        {
            ((IDictionary)this.baseDictionary).CopyTo(array, index);
        }

        int ICollection.Count
        {
            get { return this.Count; }
        }

        bool ICollection.IsSynchronized
        {
            get { return ((IDictionary)this.baseDictionary).IsSynchronized; }
        }

        object ICollection.SyncRoot
        {
            get { return ((IDictionary)this.baseDictionary).SyncRoot; }
        }
    }
}
