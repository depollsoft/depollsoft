﻿using System;
using System.Windows.Data;
using System.Windows.Markup;

namespace SLaB.Utilities.Xaml.Converters
{
    /// <summary>
    /// Creates a DependencyObject that wraps an IValueConverter.
    /// </summary>
    [ContentProperty("Converter")]
    public class ComposableConverter : IValueConverter
    {
        /// <summary>
        /// Proxies the call into the Converter.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return Converter.Convert(value, targetType, parameter, culture);
        }

        /// <summary>
        /// Proxies the call into the Converter.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return Converter.ConvertBack(value, targetType, parameter, culture);
        }

        /// <summary>
        /// Gets or sets the Converter for this ComposableConverter.
        /// </summary>
        public IValueConverter Converter { get; set; }
    }
}
