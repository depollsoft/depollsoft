﻿using System.ComponentModel;

namespace SLaB.Utilities.ChangeLinq
{
    /// <summary>
    /// Represents a value that can change over time.
    /// </summary>
    /// <typeparam name="T">The type of the value that the IChangeValue represents.</typeparam>
    public interface IChangeValue<out T> : INotifyPropertyChanged
    {
        /// <summary>
        /// The current value of the item.
        /// </summary>
        T Value { get; }
    }
    internal class ChangeValue<T> : IChangeValue<T>, INotifyPropertyChanged, IRefreshable
    {
        private T value;
        public T Value
        {
            get
            {
                return value;
            }
            protected set
            {
                T oldValue = this.value;
                this.value = value;
                if (!object.Equals(oldValue, value))
                    OnPropertyChanged("Value");
            }
        }
        protected virtual void OnPropertyChanged(string propertyName)
        {
            var pc = PropertyChanged;
            if (pc != null)
                pc(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;

        public virtual void Refresh()
        {
            if (Value is IRefreshable)
                ((IRefreshable)Value).Refresh();
        }
    }
}
