﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace SLaB.Utilities.ChangeLinq
{
    internal class WhereObservableCollection<T> : ChangeLinqBase<T>
    {
        private IEnumerable<T> original;
        private Func<T, bool> predicate;
        private List<int> mappings;
        public WhereObservableCollection(IEnumerable<T> original, Func<T, bool> predicate)
        {
            this.predicate = predicate;
            mappings = new List<int>();
            this.original = original;
        }

        protected override void AttachToSource()
        {
            if (original is INotifyCollectionChanged)
                ((INotifyCollectionChanged)original).CollectionChanged += WhereObservableCollection_CollectionChanged;
            SuppressChangeNotifications++;
            Reset();
            SuppressChangeNotifications--;
        }
        protected override void DetachFromSource()
        {
            if (original is INotifyCollectionChanged)
                ((INotifyCollectionChanged)original).CollectionChanged -= WhereObservableCollection_CollectionChanged;
        }

        private int GetNextIndex(int unmappedIndex)
        {
            if (unmappedIndex <= 0) return 0;
            if (unmappedIndex >= mappings.Count) return this.Count;
            if (mappings[unmappedIndex] >= 0)
                return mappings[unmappedIndex];
            var result = from item in mappings.Skip(unmappedIndex + 1)
                         where item >= 0
                         select item;
            if (result.Count() > 0)
                return result.First();
            result = from item in mappings.Take(unmappedIndex)
                     where item >= 0
                     select item;
            if (result.Count() > 0)
                return result.Last() + 1;
            throw new Exception("This should never be reached");
        }

        private void RefreshMappings()
        {
            int soFar = 0;
            for (int x = 0; x < mappings.Count; x++)
                if (mappings[x] >= 0)
                    mappings[x] = soFar++;
        }

        private void WhereObservableCollection_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            int startIndex;
            List<T> added = new List<T>();
            List<T> removed = new List<T>();
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    startIndex = GetNextIndex(e.NewStartingIndex);
                    foreach (var item in e.NewItems.Cast<T>().Reverse())
                    {
                        DelayChangeNotifications = true;
                        if (predicate(item))
                        {
                            added.Insert(0, item);
                            this.Items.Insert(startIndex, item);
                            mappings.Insert(e.NewStartingIndex, 0);
                        }
                        else
                            mappings.Insert(e.NewStartingIndex, -1);
                        RefreshMappings();
                        DelayChangeNotifications = false;
                    }
                    break;
                case NotifyCollectionChangedAction.Remove:
                    startIndex = GetNextIndex(e.OldStartingIndex);
                    for (int x = e.OldStartingIndex; x < e.OldStartingIndex + e.OldItems.Count; x++)
                    {
                        DelayChangeNotifications = true;
                        if (mappings[x] >= 0)
                        {
                            removed.Add(this.Items[mappings[x]]);
                            this.Items.RemoveAt(mappings[x] - removed.Count + 1);
                        }
                        mappings.RemoveAt(x);
                        RefreshMappings();
                        DelayChangeNotifications = false;
                    }
                    break;
                case NotifyCollectionChangedAction.Replace:
                    SuppressChangeNotifications++;
                    startIndex = GetNextIndex(e.NewStartingIndex);
                    for (int x = e.NewStartingIndex; x < e.NewStartingIndex + e.OldItems.Count; x++)
                    {
                        if (mappings[x] >= 0)
                        {
                            removed.Add(this.Items[mappings[x]]);
                            this.Items.RemoveAt(mappings[x] - removed.Count + 1);
                        }
                        mappings.RemoveAt(x);
                    }
                    RefreshMappings();
                    foreach (var item in e.NewItems.Cast<T>().Reverse())
                    {
                        if (predicate(item))
                        {
                            added.Insert(0, item);
                            this.Items.Insert(startIndex, item);
                            mappings.Insert(e.NewStartingIndex, 0);
                        }
                        else
                        {
                            mappings.Insert(e.NewStartingIndex, -1);
                        }
                    }
                    RefreshMappings();
                    SuppressChangeNotifications--;
                    if (added.Count > 0 && removed.Count > 0)
                    {
                        RaisePropertyChanged("Count");
                        RaisePropertyChanged("Item[]");
                        RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace, added.Single(), removed.Single(), startIndex));
                    }
                    else if (added.Count > 0)
                    {
                        RaisePropertyChanged("Count");
                        RaisePropertyChanged("Item[]");
                        RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, added.Single(), startIndex));
                    }
                    else if (removed.Count > 0)
                    {
                        RaisePropertyChanged("Count");
                        RaisePropertyChanged("Item[]");
                        RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, removed.Single(), startIndex));
                    }
                    break;
                case NotifyCollectionChangedAction.Reset:
                    Reset();
                    break;
            }
        }

        public void Reset()
        {
            this.SuppressChangeNotifications++;
            this.Items.Clear();
            this.mappings.Clear();
            int index = 0;
            int mappedIndex = 0;
            foreach (var item in original)
            {
                if (predicate(item))
                {
                    mappings.Add(mappedIndex++);
                    this.Items.Add(item);
                }
                else
                    mappings.Add(-1);
                index++;
            }
            this.SuppressChangeNotifications--;
            RaisePropertyChanged("Count");
            RaisePropertyChanged("Item[]");
            RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        public override void Refresh()
        {
            if (original is IRefreshable)
                ((IRefreshable)original).Refresh();
            Reset();
        }
    }
}
