﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace SLaB.Utilities.ChangeLinq
{
    internal class Aggregator<TIn, TOut> : ChangeValue<TOut>, IRefreshable
    {
        private IEnumerable<TIn> original;
        private Func<TOut, TIn, TOut> aggregator;
        private TOut initialValue;
        public Aggregator(IEnumerable<TIn> original, Func<TOut, TIn, TOut> aggregator, TOut initialValue = default(TOut))
        {
            this.aggregator = aggregator;
            this.initialValue = initialValue;
            if (!(original is INotifyCollectionChanged))
                this.original = original.ToArray();
            else
            {
                this.original = original;
                ((INotifyCollectionChanged)original).CollectionChanged += Aggregator_CollectionChanged;
            }
            Reset();
        }

        private void Aggregator_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            TOut result = initialValue;
            foreach (var item in original)
                result = aggregator(result, item);
            this.Value = result;
        }

        public override void Refresh()
        {
            if (original is IRefreshable)
                ((IRefreshable)original).Refresh();
            Reset();
        }
    }
}
