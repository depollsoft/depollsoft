﻿using System.Collections.Generic;
using System.ComponentModel;

namespace SLaB.Utilities.ChangeLinq
{
    internal class ChangeValueWrapper<T> : SelectObservableCollection<T, T>
    {
        private IChangeValue<IEnumerable<T>> source;
        public ChangeValueWrapper(IChangeValue<IEnumerable<T>> source)
            : base(source.Value, (i) => i)
        {
            this.source = source;
        }

        void source_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            OnPropertyChanged();
        }

        private void OnPropertyChanged()
        {
            this.Original = source.Value;
        }

        protected override void DetachFromSource()
        {
            source.PropertyChanged -= source_PropertyChanged;
            base.DetachFromSource();
        }

        protected override void AttachToSource()
        {
            source.PropertyChanged += source_PropertyChanged;
            base.AttachToSource();
        }
    }
}
