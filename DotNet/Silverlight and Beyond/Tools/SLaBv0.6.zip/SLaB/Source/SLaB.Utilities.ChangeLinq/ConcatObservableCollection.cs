﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace SLaB.Utilities.ChangeLinq
{
    internal class ConcatObservableCollection<T> : ChangeLinqBase<T>
    {
        private IEnumerable<T> original;
        private IEnumerable<T> concat;
        private int originalCount;
        private int concatCount;
        public ConcatObservableCollection(IEnumerable<T> original, IEnumerable<T> concat)
        {
            this.original = original;
            this.concat = concat;
        }

        protected override void AttachToSource()
        {
            if (original is INotifyCollectionChanged)
                ((INotifyCollectionChanged)original).CollectionChanged += ConcatObservableCollection_CollectionChanged;
            if (concat is INotifyCollectionChanged)
                ((INotifyCollectionChanged)concat).CollectionChanged += ConcatObservableCollection_CollectionChanged;
            SuppressChangeNotifications++;
            Reset();
            SuppressChangeNotifications--;
        }
        protected override void DetachFromSource()
        {
            if (original is INotifyCollectionChanged)
                ((INotifyCollectionChanged)original).CollectionChanged -= ConcatObservableCollection_CollectionChanged;
            if (concat is INotifyCollectionChanged)
                ((INotifyCollectionChanged)concat).CollectionChanged -= ConcatObservableCollection_CollectionChanged;
        }

        private int TranslateIndex(object sender, int index)
        {
            if (sender == original)
                return index;
            return originalCount + index;
        }

        private void AddToCount(object sender, int toAdd)
        {
            if (sender == original)
                originalCount += toAdd;
            else
                concatCount += toAdd;
        }

        private void ConcatObservableCollection_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            int startIndex;
            List<T> added = new List<T>();
            List<T> removed = new List<T>();
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    startIndex = TranslateIndex(sender, e.NewStartingIndex);
                    foreach (var item in e.NewItems.Cast<T>().Reverse())
                    {
                        DelayChangeNotifications = true;
                        added.Insert(0, item);
                        this.Items.Insert(startIndex, item);
                        AddToCount(sender, 1);
                        DelayChangeNotifications = false;
                    }
                    break;
                case NotifyCollectionChangedAction.Remove:
                    startIndex = TranslateIndex(sender, e.OldStartingIndex);
                    foreach (var item in e.OldItems.Cast<T>().Reverse())
                    {
                        DelayChangeNotifications = true;
                        removed.Add(this.Items[startIndex]);
                        this.Items.RemoveAt(startIndex);
                        AddToCount(sender, -1);
                        DelayChangeNotifications = false;
                    }
                    break;
                case NotifyCollectionChangedAction.Replace:
                    SuppressChangeNotifications++;
                    startIndex = TranslateIndex(sender, e.NewStartingIndex);
                    foreach (var item in e.OldItems.Cast<T>().Reverse())
                    {
                        removed.Add(this.Items[startIndex]);
                        this.Items.RemoveAt(startIndex);
                        AddToCount(sender, -1);
                    }
                    foreach (var item in e.NewItems.Cast<T>().Reverse())
                    {
                        added.Insert(0, item);
                        this.Items.Insert(startIndex, item);
                        AddToCount(sender, 1);
                    }
                    SuppressChangeNotifications--;
                    RaisePropertyChanged("Count");
                    RaisePropertyChanged("Item[]");
                    RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace, added.Single(), removed.Single(), startIndex));
                    break;
                case NotifyCollectionChangedAction.Reset:
                    Reset();
                    break;
            }
        }

        private void Reset()
        {
            SuppressChangeNotifications++;
            this.Items.Clear();
            originalCount = 0;
            concatCount = 0;
            foreach (var item in original)
            {
                this.Items.Add(item);
                originalCount++;
            }
            foreach (var item in concat)
            {
                this.Items.Add(item);
                concatCount++;
            }
            SuppressChangeNotifications--;
            RaisePropertyChanged("Count");
            RaisePropertyChanged("Item[]");
            RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        public override void Refresh()
        {
            if (original is IRefreshable)
                ((IRefreshable)original).Refresh();
            if (concat is IRefreshable)
                ((IRefreshable)concat).Refresh();
            Reset();
        }
    }
}
