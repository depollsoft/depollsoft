﻿using System;
using System.Collections.Generic;

namespace SLaB.Utilities.ChangeLinq
{
    internal abstract class ChangeLinqBase<T> : ObservableCollectionBase<T>, IChangeLinq<T>, IRefreshable, IList<T>
    {
        protected override void ListenerAdded()
        {
            if (ListenerCount == 1)
                AttachToSource();
        }
        protected override void ListenerRemoved()
        {
            if (ListenerCount == 0)
                DetachFromSource();
        }

        protected abstract void AttachToSource();
        protected abstract void DetachFromSource();

        public override System.Collections.Generic.IEnumerator<T> GetEnumerator()
        {
            if (ListenerCount == 0)
                this.Refresh();
            return base.GetEnumerator();
        }

        public abstract void Refresh();

        int IList<T>.IndexOf(T item)
        {
            if (ListenerCount == 0)
                this.Refresh();
            return Items.IndexOf(item);
        }

        void IList<T>.Insert(int index, T item)
        {
            throw new InvalidOperationException("Collection is Read-Only");
        }

        void IList<T>.RemoveAt(int index)
        {
            throw new InvalidOperationException("Collection is Read-Only");
        }

        T IList<T>.this[int index]
        {
            get
            {
                if (ListenerCount == 0)
                    this.Refresh();
                return Items[index];
            }
            set
            {
                throw new InvalidOperationException("Collection is Read-Only");
            }
        }

        void ICollection<T>.Add(T item)
        {
            throw new NotImplementedException();
        }

        void ICollection<T>.Clear()
        {
            throw new InvalidOperationException("Collection is Read-Only");
        }

        bool ICollection<T>.Contains(T item)
        {
            if (ListenerCount == 0)
                this.Refresh();
            return Items.Contains(item);
        }

        void ICollection<T>.CopyTo(T[] array, int arrayIndex)
        {
            if (ListenerCount == 0)
                this.Refresh();
            Items.CopyTo(array, arrayIndex);
        }

        int ICollection<T>.Count
        {
            get
            {
                if (ListenerCount == 0)
                    this.Refresh();
                return Items.Count;
            }
        }

        bool ICollection<T>.IsReadOnly
        {
            get
            {
                return true;
            }
        }

        bool ICollection<T>.Remove(T item)
        {
            throw new InvalidOperationException("Collection is Read-Only");
        }
    }
}
