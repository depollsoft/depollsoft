﻿using System;
using System.Windows.Input;

namespace SLaB.Utilities
{
    /// <summary>
    /// An ICommand that can be created easily using lambdas and explicitly refreshed.
    /// </summary>
    /// <typeparam name="T">The CommandParameter type.</typeparam>
    public class LambdaCommand<T> : ICommand
    {
        private Action<T> execute;
        private Func<T, bool> canExecute;
        /// <summary>
        /// Constructs a LambdaCommand.
        /// </summary>
        /// <param name="execute">The action to execute.</param>
        /// <param name="canExecute">The CanExecute predicate for the command.</param>
        public LambdaCommand(Action<T> execute, Func<T, bool> canExecute = null)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");
            if (canExecute == null)
                canExecute = (parameter) => true;
            this.execute = execute;
            this.canExecute = canExecute;
        }

        /// <summary>
        /// Raises CanExecuteChanged on the LambdaCommand.
        /// </summary>
        public void RefreshCanExecute()
        {
            CanExecuteChanged.Raise(this, new EventArgs());
        }

        /// <summary>
        /// Indicates whether the command can be executed.
        /// </summary>
        /// <param name="parameter">The CommandParameter.</param>
        /// <returns>true if the command can be executed.  false otherwise.</returns>
        public bool CanExecute(object parameter)
        {
            if (!(parameter is T) && parameter != null)
                return false;
            return canExecute((T)parameter);
        }

        /// <summary>
        /// Indicates that the result of CanExecute may have changed.
        /// </summary>
        public event EventHandler CanExecuteChanged;

        /// <summary>
        /// Executes the command with the given parameter.
        /// </summary>
        /// <param name="parameter">The CommandParameter.</param>
        public void Execute(object parameter)
        {
            if (!CanExecute(parameter))
                return;
            execute((T)parameter);
        }
    }
}
