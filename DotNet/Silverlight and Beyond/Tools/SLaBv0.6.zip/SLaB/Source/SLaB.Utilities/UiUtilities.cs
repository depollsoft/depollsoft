﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace SLaB.Utilities
{
    /// <summary>
    /// A collection of useful functions for working with UI in Silverlight.
    /// </summary>
    public static class UiUtilities
    {
        private static Thread UiThread { get; set; }
        private static ManualResetEvent initResetter = new ManualResetEvent(false);
        private static Dispatcher Dispatcher;

        /// <summary>
        /// Sets up UiUtilities for use.  Only needs to be called explicitly in design mode.
        /// </summary>
        public static void InitializeExecuteOnUiThread()
        {
            try
            {
                var visual = Application.Current.RootVisual;
                Dispatcher = visual.Dispatcher;
                UiThread = Thread.CurrentThread;
                initResetter.Set();
            }
            catch
            {
                Dispatcher = Deployment.Current.Dispatcher;
                Dispatcher.BeginInvoke(() =>
                {
                    UiThread = Thread.CurrentThread;
                    initResetter.Set();
                });
            }
        }

        /// <summary>
        /// Executes a function on the UI thread, blocking until the result has been retrieved.
        /// This method is safe to use whether or not execution is already on the UI thread, since
        /// it only switches threads if necessary.
        /// </summary>
        /// <typeparam name="T">The return type of the function.</typeparam>
        /// <param name="func">The function to execute (usually a lambda).</param>
        /// <returns>The value returned by the function.</returns>
        /// <exception cref="System.Exception">Any exception thrown by the function will be re-thrown by this method
        /// on the initiating thread.</exception>
        public static T ExecuteOnUiThread<T>(Func<T> func)
        {
            if (UiThread == null)
            {
                InitializeExecuteOnUiThread();
                initResetter.WaitOne();
            }
            if (Thread.CurrentThread.Equals(UiThread))
            {
                return func();
            }
            else
            {
                T result = default(T);
                object waitLock = new object();
                Exception error = null;
                lock (waitLock)
                {
                    Dispatcher.BeginInvoke(() =>
                    {
                        try
                        {
                            result = func();
                        }
                        catch (Exception e)
                        {
                            error = e;
                        }
                        lock (waitLock) Monitor.Pulse(waitLock);
                    });
                    Monitor.Wait(waitLock);
                }
                if (error != null)
                    throw error;
                return result;
            }
        }

        /// <summary>
        /// Executes an action on the UI thread, blocking until the execution has completed.
        /// This method is safe to use whether or not execution is already on the UI thread, since
        /// it only switches threads if necessary.
        /// </summary>
        /// <param name="action">The action to execute (usually a lambda).</param>
        /// <exception cref="System.Exception">Any exception thrown by the action will be re-thrown by this method
        /// on the initiating thread.</exception>
        public static void ExecuteOnUiThread(Action action)
        {
            ExecuteOnUiThread<object>(() =>
            {
                action();
                return null;
            });
        }

        /// <summary>
        /// Invokes a delegate (or no-ops if the delegate is null).
        /// </summary>
        /// <param name="del">The delegate to invoke.</param>
        /// <param name="arguments">Arguments to the delegate.</param>
        /// <returns>The value returned by the delegate.  Null if the delegate is null.</returns>
        public static object Raise(this Delegate del, params object[] arguments)
        {
            if (del != null)
                return del.DynamicInvoke(arguments);
            return null;
        }

        /// <summary>
        /// Raises an EventHandler&lt;T&gt; or no-ops if the event handler is null.
        /// </summary>
        /// <typeparam name="T">The type of EventArgs for the event handler.</typeparam>
        /// <param name="eh">The event handler to raise.</param>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The event arguments.</param>
        public static void Raise<T>(this EventHandler<T> eh, object sender, T args) where T : EventArgs
        {
            if (eh != null)
                eh(sender, args);
        }

        /// <summary>
        /// Delays taking some action by enqueuing dispatcher BeginInvokes until the condition is true.
        /// </summary>
        /// <param name="dispatcher">The dispatcher to use.</param>
        /// <param name="action">The action to take.</param>
        /// <param name="condition">The condition to be met before taking the action.</param>
        public static void DelayUntil(this Dispatcher dispatcher, Action action, Func<bool> condition)
        {
            if (!condition())
                Dispatcher.BeginInvoke(() => dispatcher.DelayUntil(action, condition));
            else
                action();
        }
    }
}
