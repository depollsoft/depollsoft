﻿using System;
using System.Linq.Expressions;
using System.Reflection;

namespace SLaB.Utilities
{
    /// <summary>
    /// Provides a set of methods that can be used to simplify reflection operations.
    /// </summary>
    public static class ReflectionUtilities
    {
        /// <summary>
        /// Gets the MethodInfo for a method call in the expression passed in.  Also works for private methods.
        /// </summary>
        /// <typeparam name="T">The delegate type from which to get the expression.</typeparam>
        /// <param name="expression">The expression to use to get the MethodInfo.</param>
        /// <returns>The MethodInfo for the last method call in the expression.</returns>
        public static MethodInfo GetMethodInfo<T>(Expression<T> expression)
        {
            LambdaExpression expr = (LambdaExpression)expression;
            if (expr.Body.NodeType != ExpressionType.Call)
                throw new ArgumentException();
            MethodCallExpression mcExpr = (MethodCallExpression)expr.Body;
            return mcExpr.Method;
        }
    }
}
