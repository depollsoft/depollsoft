﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Resources;
using SLaB.Navigation.ContentLoaders.Utilities;
using SLaB.Utilities;
using xap = SLaB.Utilities.Xap;

namespace SLaB.Navigation.ContentLoaders.Xap
{
    /// <summary>
    /// An INavigationContentLoader that loads a page within a given Xap.
    /// </summary>
    public class XapPageResourceContentLoader : ContentLoaderBase
    {
        static XapPageResourceContentLoader()
        {
            PackUriParser.Initialize();
        }

        /// <summary>
        /// Gets or sets the Xap from which the XapPageResourceContentLoader should load.
        /// </summary>
        public xap.Xap Xap
        {
            get { return (xap.Xap)GetValue(XapProperty); }
            set { SetValue(XapProperty, value); }
        }

        /// <summary>
        /// Gets or sets the Xap from which the XapPageResourceContentLoader should load.
        /// </summary>
        public static readonly DependencyProperty XapProperty =
            DependencyProperty.Register("Xap", typeof(xap.Xap), typeof(XapPageResourceContentLoader), new PropertyMetadata(null));

        /// <summary>
        /// Creates an instance of a LoaderBase that will be used to handle loading.
        /// </summary>
        /// <returns>An instance of a LoaderBase.</returns>
        protected override LoaderBase CreateLoader()
        {
            return new Loader(this);
        }

        private class Loader : LoaderBase
        {
            private Regex XClassRegex = new Regex(".*x:Class=\"(?<className>.*?)\"", RegexOptions.CultureInvariant);
            private XapPageResourceContentLoader loader;
            public Loader(XapPageResourceContentLoader loader)
            {
                this.loader = loader;
            }
            public override void Load(Uri targetUri, Uri currentUri)
            {
                PackUriHelper helper = new PackUriHelper(targetUri);
                string assemblyName = helper.AssemblyName ?? UiUtilities.ExecuteOnUiThread(() => loader.Xap.Manifest.EntryPointAssembly);
                StreamResourceInfo xamlStream = Application.GetResourceStream(new Uri("/" + assemblyName + ";component" + helper.Path, UriKind.Relative));
                StreamReader reader = new StreamReader(xamlStream.Stream);
                string xaml = reader.ReadToEnd();
                string typeName = GetTypeName(xaml);
                object value;
                if (typeName != null)
                {
                    var assembly = (from asm in loader.Xap.Assemblies
                                    where asm.FullName.Split(',')[0].Equals(assemblyName, StringComparison.CurrentCultureIgnoreCase)
                                    select asm).SingleOrDefault();
                    value = UiUtilities.ExecuteOnUiThread(() => Activator.CreateInstance(assembly.GetType(typeName, true)));
                }
                else
                    value = UiUtilities.ExecuteOnUiThread(() => XamlReader.Load(xaml));
                Complete(value);
            }

            private string GetTypeName(string xaml)
            {
                Group g = XClassRegex.Match(xaml).Groups["className"];
                if (g.Success)
                    return g.Value;
                return null;
            }

            public override void Cancel()
            {
            }
        }

    }
}
