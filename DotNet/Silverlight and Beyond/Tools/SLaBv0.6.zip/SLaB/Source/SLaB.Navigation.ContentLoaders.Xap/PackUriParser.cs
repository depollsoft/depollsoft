﻿using System;
using System.Text.RegularExpressions;

namespace SLaB.Navigation.ContentLoaders.Xap
{
    /// <summary>
    /// A UriParser for pack Uris.
    /// </summary>
    public class PackUriParser : UriParser
    {
        static PackUriParser()
        {
            Initialize();
        }

        private static bool isInitialized=false;
        /// <summary>
        /// Registers the PackUriParser so that pack Uris can be created.  Call this method at least once in any application that will create
        /// pack Uris.
        /// </summary>
        public static void Initialize()
        {
            if (!isInitialized)
            {
                UriParser.Register(new PackUriParser(), "pack", -1);
                isInitialized = true;
            }
        }

        private static readonly Regex uriRegex = new Regex(@"^pack://(?<authority>.*?)(?<path>/.*?)?(\?(?<querystring>.*?))?(#(?<fragment>.*?))?$");
        private string authority;
        private string path;
        private string port;
        private string queryString;
        private string fragment;
        private int registeredPort;

        /// <summary>
        /// Constructs a PackUriParser.
        /// </summary>
        public PackUriParser()
        {
        }

        /// <summary>
        /// Gets the components from a Uri.
        /// </summary>
        /// <param name="uri">The System.Uri to parse.</param>
        /// <param name="components">The System.UriComponents to retrieve from uri.</param>
        /// <param name="format">One of the System.UriFormat values that controls how special characters are escaped.</param>
        /// <returns>A string that contains the components.</returns>
        /// <exception cref="System.ArgumentOutOfRangeException">format is invalid- or -components is not a combination of valid System.UriComponents values.</exception>
        /// <exception cref="System.InvalidOperationException">uri requires user-driven parsing- or -uri is not an absolute URI. Relative URIs cannot be used with this method.</exception>
        protected override string GetComponents(Uri uri, UriComponents components, UriFormat format)
        {
            if (components.HasFlag(UriComponents.AbsoluteUri))
            {
                return uri.OriginalString;
            }
            else if (components.HasFlag(UriComponents.Fragment))
            {
                return fragment;
            }
            else if (components.HasFlag(UriComponents.Host))
            {
                return authority;
            }
            else if (components.HasFlag(UriComponents.HostAndPort))
            {
                return authority + ":" + port;
            }
            else if (components.HasFlag(UriComponents.Path))
            {
                return path;
            }
            else if (components.HasFlag(UriComponents.PathAndQuery))
            {
                return path + "?" + queryString;
            }
            else if (components.HasFlag(UriComponents.Port))
            {
                return port;
            }
            else if (components.HasFlag(UriComponents.Query))
            {
                return queryString;
            }
            else if (components.HasFlag(UriComponents.Scheme))
            {
                return "pack";
            }
            else if (components.HasFlag(UriComponents.SchemeAndServer))
            {
                return "pack://" + authority;
            }
            else if (components.HasFlag(UriComponents.StrongAuthority))
            {
                return authority;
            }
            else if (components.HasFlag(UriComponents.StrongPort))
            {
                return port;
            }
            else if (components.HasFlag(UriComponents.UserInfo))
            {
                return "";
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Initialize the state of the parser and validate the Uri.
        /// </summary>
        /// <param name="uri">The System.Uri to validate.</param>
        /// <param name="parsingError">Validation errors, if any.</param>
        protected override void InitializeAndValidate(Uri uri, out UriFormatException parsingError)
        {
            parsingError = null;
            Match m = uriRegex.Match(uri.OriginalString);
            if (!m.Success)
                parsingError = new UriFormatException("Uri did not match pack uri syntax");
            authority = m.Groups["authority"].Value;
            path = m.Groups["path"].Value;
            port = registeredPort.ToString();
            queryString = m.Groups["querystring"].Value;
            fragment = m.Groups["fragment"].Value;
        }

        /// <summary>
        /// Invoked by a System.Uri constructor to get a System.UriParser instance
        /// </summary>
        /// <returns>A System.UriParser for the constructed System.Uri.</returns>
        protected override UriParser OnNewUri()
        {
            return new PackUriParser() { registeredPort = this.registeredPort };
        }

        /// <summary>
        /// Invoked by the Framework when a System.UriParser method is registered.
        /// </summary>
        /// <param name="schemeName">The scheme that is associated with this System.UriParser.</param>
        /// <param name="defaultPort">The port number of the scheme.</param>
        protected override void OnRegister(string schemeName, int defaultPort)
        {
            registeredPort = defaultPort;
        }

        /// <summary>
        /// Called by System.Uri constructors and Overload:System.Uri.TryCreate to resolve a relative Uri.
        /// </summary>
        /// <param name="baseUri">A base URI.</param>
        /// <param name="relativeUri">A relative URI.</param>
        /// <param name="parsingError">Errors during the resolve process, if any.</param>
        /// <returns>The string of the resolved relative System.Uri.</returns>
        protected override string Resolve(Uri baseUri, Uri relativeUri, out UriFormatException parsingError)
        {
            string result = baseUri.OriginalString;
            string addition = relativeUri.OriginalString;
            parsingError = null;
            if (result.EndsWith("/"))
                result = result.Substring(0, result.Length - 1);
            if (addition.StartsWith("/"))
                addition = addition.Substring(1);
            return result + "/" + addition;
        }
    }
}
