﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using SLaB.Navigation.Utilities;

namespace SLaB.Navigation.ContentLoaders.Xap
{
    /// <summary>
    /// A UriMapping to simplify creating Uris for the XapContentLoader.  This allows developers to avoid using
    /// pack Uris altogether.
    /// </summary>
    public class PackUriMapping : IUriMapping
    {
        static PackUriMapping()
        {
            PackUriParser.Initialize();
        }
        /// <summary>
        /// Token that can be used in patterns in lieu of setting the AssemblyName property.
        /// </summary>
        public static readonly string AssemblyNameToken = "assemblyname";

        /// <summary>
        /// Uri to the Xap in which the page being navigated to can be found.  This property must be set in order
        /// for mapping to occur.
        /// </summary>
        public Uri XapLocation { get; set; }

        /// <summary>
        /// The name of the assembly within the Xap where the page can be found.
        /// </summary>
        public string AssemblyName { get; set; }
        private string mappedPath;

        /// <summary>
        /// Gets or sets the resulting path after running the mapping.  This is equivalent to the UriMapping.MappedUri property,
        /// but only represents the path at the end of the pack Uri.
        /// </summary>
        public string MappedPath
        {
            get { return mappedPath; }
            set { mappedPath = value; UpdatePattern(); }
        }
        private Uri uri;
        /// <summary>
        /// Gets or sets the pattern to match when determining if the requested uniform resource identifier (Uri) is converted to a mapped Uri.
        /// </summary>
        public Uri Uri
        {
            get { return uri; }
            set { uri = value; UpdatePattern(); }
        }

        private static readonly Regex patternRegex = new Regex(@"\\\{(?<name>.*?)\}");

        private Regex matcher;
        private Dictionary<string, string> seen;

        private void UpdatePattern()
        {
            if (MappedPath == null || Uri == null)
                return;
            seen = new Dictionary<string, string>();
            string pattern = Uri.OriginalString;
            pattern = Regex.Escape(pattern);
            pattern = patternRegex.Replace(pattern, (match) =>
            {
                string name = match.Groups["name"].Value;
                if (seen.ContainsKey(name))
                    return string.Format("${{{0}}}", name);
                string final = string.Format("(?<{0}>.*?)", name);
                seen[name] = string.Format(@"\{{{0}\}}", name);
                return final;
            });
            matcher = new Regex("^" + pattern + "$", RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// Converts the specified uniform resource identifier (Uri) to a new Uri, if the specified Uri matches the defined template for converting.
        /// </summary>
        /// <param name="uri">The Uri to convert.</param>
        /// <returns>The Uri that has been converted or null if the Uri cannot be converted.</returns>
        public Uri MapUri(Uri uri)
        {
            if (XapLocation == null)
                return null;
            Match matches = matcher.Match(uri.OriginalString);
            if (!matches.Success)
                return null;
            string path = MappedPath;
            foreach (string key in seen.Keys)
                path = new Regex(seen[key], RegexOptions.IgnoreCase).Replace(path, matches.Groups[key].Value);
            return PackUriHelper.BuildPackUri(XapLocation ?? new Uri("application:///"), path, AssemblyName ?? matches.Groups[AssemblyNameToken].Value);
        }
    }
}
