﻿using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using SLaB.Utilities;

namespace SLaB.Controls.Phone
{
    [StyleTypedProperty(Property = "FrameStyle", StyleTargetType = typeof(PhoneApplicationFrame))]
    [StyleTypedProperty(Property = "ForwardTransitionStyle", StyleTargetType = typeof(RichTransitionContentControl))]
    [StyleTypedProperty(Property = "BackTransitionStyle", StyleTargetType = typeof(RichTransitionContentControl))]
    public static class RichFraming
    {
        static RichFraming()
        {
            UiUtilities.Dispatcher.DelayUntil(() =>
                {
                    RootFrame.Navigating += (obj, args) => SetNavigationMode(RootFrame, args.NavigationMode);
                }, () => RootFrame != null);
        }

        public static PhoneApplicationFrame RootFrame
        {
            get
            {
                return Application.Current.RootVisual as PhoneApplicationFrame;
            }
        }
        public static Style GetFrameStyle(ResourceDictionary obj)
        {
            return (Style)obj.GetValue(FrameStyleProperty);
        }
        public static void SetFrameStyle(ResourceDictionary obj, Style value)
        {
            obj.SetValue(FrameStyleProperty, value);
        }



        public static Style GetForwardTransitionStyle(PhoneApplicationFrame obj)
        {
            return (Style)obj.GetValue(ForwardTransitionStyleProperty);
        }

        public static void SetForwardTransitionStyle(PhoneApplicationFrame obj, Style value)
        {
            obj.SetValue(ForwardTransitionStyleProperty, value);
        }

        // Using a DependencyProperty as the backing store for ForwardTransitionStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ForwardTransitionStyleProperty =
            DependencyProperty.RegisterAttached("ForwardTransitionStyle", typeof(Style), typeof(RichFraming), new PropertyMetadata(null, OnTransitionStyleChanged));

        public static Style GetBackTransitionStyle(PhoneApplicationFrame obj)
        {
            return (Style)obj.GetValue(BackTransitionStyleProperty);
        }

        public static void SetBackTransitionStyle(PhoneApplicationFrame obj, Style value)
        {
            obj.SetValue(BackTransitionStyleProperty, value);
        }

        // Using a DependencyProperty as the backing store for BackTransitionStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty BackTransitionStyleProperty =
            DependencyProperty.RegisterAttached("BackTransitionStyle", typeof(Style), typeof(RichFraming), new PropertyMetadata(null, OnTransitionStyleChanged));

        private static void OnTransitionStyleChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
        }

        public static NavigationMode GetNavigationMode(PhoneApplicationFrame obj)
        {
            return (NavigationMode)obj.GetValue(NavigationModeProperty);
        }

        public static void SetNavigationMode(PhoneApplicationFrame obj, NavigationMode value)
        {
            obj.SetValue(NavigationModeProperty, value);
        }

        // Using a DependencyProperty as the backing store for NavigationMode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NavigationModeProperty =
            DependencyProperty.RegisterAttached("NavigationMode", typeof(NavigationMode), typeof(RichFraming), new PropertyMetadata(NavigationMode.New));


        // Using a DependencyProperty as the backing store for FrameStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FrameStyleProperty =
            DependencyProperty.RegisterAttached("FrameStyle", typeof(Style), typeof(RichFraming), new PropertyMetadata(null, OnFrameStyleChanged));

        private static void OnFrameStyleChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            SetupFrameStyle((Style)args.NewValue);
        }
        private static void SetupFrameStyle(Style newStyle)
        {
            UiUtilities.Dispatcher.DelayUntil(() =>
                {
                    RootFrame.Style = newStyle;
                }, () => RootFrame != null);
        }
    }
}
