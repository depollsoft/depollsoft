﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using System.Globalization;
using System.Windows.Navigation;

namespace SLaB.Controls.Phone
{
    public class ForwardBackNavigationConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value.Equals(NavigationMode.Back))
                return RichFraming.GetBackTransitionStyle(RichFraming.RootFrame);
            else
                return RichFraming.GetForwardTransitionStyle(RichFraming.RootFrame);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
