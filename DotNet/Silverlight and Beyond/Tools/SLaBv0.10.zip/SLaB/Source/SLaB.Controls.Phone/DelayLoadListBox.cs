﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using SLaB.Utilities;
using System.Windows.Data;
using System.Windows.Threading;

namespace SLaB.Controls.Phone
{
    public class DelayLoadListBox : ListBox
    {
        private ScrollViewer _ScrollViewer;
        private DispatcherTimer _Timer;
        public DelayLoadListBox()
        {
            this.DelayLoadAction += (s, args) =>
                {
                    if (DelayLoadCommand != null && DelayLoadCommand.CanExecute(null))
                        DelayLoadCommand.Execute(null);
                };
            this.Loaded += (s, args) =>
                {
                    _Timer = new DispatcherTimer();
                    _Timer.Tick += TimerTick;
                };
            this.Unloaded += (s, args) =>
                {
                    _Timer.Tick -= TimerTick;
                    _Timer = null;
                };
        }

        private void TimerTick(object sender, EventArgs e)
        {
            if (HasMoreItems && _ScrollViewer != null && Math.Abs(_ScrollViewer.VerticalOffset - _ScrollViewer.ScrollableHeight) < DelayLoadTriggerDistance)
                DelayLoadAction.Raise(this, new EventArgs());
            else
                _Timer.Stop();
        }

        protected override void OnItemsChanged(System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (HasMoreItems && _ScrollViewer != null && Math.Abs(_ScrollViewer.VerticalOffset - _ScrollViewer.ScrollableHeight) < DelayLoadTriggerDistance)
            {
                DelayLoadAction.Raise(this, new EventArgs());
                _Timer.Interval = RetryTime;
                _Timer.Start();
            }
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            _ScrollViewer = GetTemplateChild("ScrollViewer") as ScrollViewer;
            Binding b = new Binding("VerticalOffset");
            b.Source = _ScrollViewer;
            SetBinding(VerticalOffsetProperty, b);
        }


        public bool HasMoreItems
        {
            get { return (bool)GetValue(HasMoreItemsProperty); }
            set { SetValue(HasMoreItemsProperty, value); }
        }

        public static readonly DependencyProperty HasMoreItemsProperty =
            DependencyProperty.Register("HasMoreItems", typeof(bool), typeof(DelayLoadListBox), new PropertyMetadata(true, OnHasMoreItemsChanged));

        private static void OnHasMoreItemsChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((DelayLoadListBox)obj).OnHasMoreItemsChanged((bool)args.OldValue, (bool)args.NewValue);
        }

        private void OnHasMoreItemsChanged(bool oldValue, bool newValue)
        {
            if (HasMoreItems && _ScrollViewer != null && Math.Abs(_ScrollViewer.VerticalOffset - _ScrollViewer.ScrollableHeight) < DelayLoadTriggerDistance)
            {
                DelayLoadAction.Raise(this, new EventArgs());
                _Timer.Interval = RetryTime;
                _Timer.Start();
            }
        }

        public TimeSpan RetryTime
        {
            get { return (TimeSpan)GetValue(RetryTimeProperty); }
            set { SetValue(RetryTimeProperty, value); }
        }

        public static readonly DependencyProperty RetryTimeProperty =
            DependencyProperty.Register("RetryTime", typeof(TimeSpan), typeof(DelayLoadListBox), new PropertyMetadata(TimeSpan.FromSeconds(0.1), OnRetryTimeChanged));

        private static void OnRetryTimeChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((DelayLoadListBox)obj).OnRetryTimeChanged((TimeSpan)args.OldValue, (TimeSpan)args.NewValue);
        }

        private void OnRetryTimeChanged(TimeSpan oldValue, TimeSpan newValue)
        {
            _Timer.Interval = newValue;
        }

        public double DelayLoadTriggerDistance
        {
            get { return (double)GetValue(DelayLoadTriggerDistanceProperty); }
            set { SetValue(DelayLoadTriggerDistanceProperty, value); }
        }

        public static readonly DependencyProperty DelayLoadTriggerDistanceProperty =
            DependencyProperty.Register("DelayLoadTriggerDistance", typeof(double), typeof(DelayLoadListBox), new PropertyMetadata(100d, OnDelayLoadTriggerDistanceChanged));

        private static void OnDelayLoadTriggerDistanceChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((DelayLoadListBox)obj).OnDelayLoadTriggerDistanceChanged((double)args.OldValue, (double)args.NewValue);
        }

        private void OnDelayLoadTriggerDistanceChanged(double oldValue, double newValue)
        {
            if (HasMoreItems && _ScrollViewer != null && Math.Abs(_ScrollViewer.VerticalOffset - _ScrollViewer.ScrollableHeight) < DelayLoadTriggerDistance)
            {
                DelayLoadAction.Raise(this, new EventArgs());
                _Timer.Interval = RetryTime;
                _Timer.Start();
            }
        }

        private double VerticalOffset
        {
            get { return (double)GetValue(VerticalOffsetProperty); }
            set { SetValue(VerticalOffsetProperty, value); }
        }

        private static readonly DependencyProperty VerticalOffsetProperty =
            DependencyProperty.Register("VerticalOffset", typeof(double), typeof(DelayLoadListBox), new PropertyMetadata(default(double), OnVerticalOffsetChanged));

        private static void OnVerticalOffsetChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((DelayLoadListBox)obj).OnVerticalOffsetChanged((double)args.OldValue, (double)args.NewValue);
        }

        private void OnVerticalOffsetChanged(double oldValue, double newValue)
        {
            if (HasMoreItems && _ScrollViewer != null && Math.Abs(_ScrollViewer.VerticalOffset - _ScrollViewer.ScrollableHeight) < DelayLoadTriggerDistance)
            {
                DelayLoadAction.Raise(this, new EventArgs());
                _Timer.Interval = RetryTime;
                _Timer.Start();
            }
        }

        public ICommand DelayLoadCommand
        {
            get { return (ICommand)GetValue(DelayLoadCommandProperty); }
            set { SetValue(DelayLoadCommandProperty, value); }
        }

        public static readonly DependencyProperty DelayLoadCommandProperty =
            DependencyProperty.Register("DelayLoadCommand", typeof(ICommand), typeof(DelayLoadListBox), new PropertyMetadata(default(ICommand), OnDelayLoadCommandChanged));

        private static void OnDelayLoadCommandChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((DelayLoadListBox)obj).OnDelayLoadCommandChanged((ICommand)args.OldValue, (ICommand)args.NewValue);
        }

        private void OnDelayLoadCommandChanged(ICommand oldValue, ICommand newValue)
        {
        }

        public event EventHandler<EventArgs> DelayLoadAction;
    }
}
