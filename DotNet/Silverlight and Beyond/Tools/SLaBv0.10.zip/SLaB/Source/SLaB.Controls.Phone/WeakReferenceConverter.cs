﻿using System;
using System.Windows.Data;

namespace SLaB.Controls.Phone
{
    public class WeakReferenceConverter : IValueConverter
    {
        public WeakReferenceConverter()
        {
        }

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return new WeakReference(value);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            WeakReference wr = value as WeakReference;
            if (wr == null || !wr.IsAlive)
                return null;
            return wr.Target;
        }
    }
}
