﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Markup;
using System.Windows.Controls.Primitives;

namespace SLaB.Controls.Phone
{
    [ContentProperty("Target")]
    public class BitmapSnapper : Control
    {
        private Size _LastSize;
        private bool _AwaitingRefresh;
        public BitmapSnapper()
        {
            DefaultStyleKey = typeof(BitmapSnapper);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
        }

        public ImageSource Bitmap
        {
            get { return (ImageSource)GetValue(BitmapProperty); }
            private set { SetValue(BitmapProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Bitmap.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty BitmapProperty =
            DependencyProperty.Register("Bitmap", typeof(ImageSource), typeof(BitmapSnapper), new PropertyMetadata(null));



        public object Target
        {
            get { return (object)GetValue(TargetProperty); }
            set { SetValue(TargetProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Target.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TargetProperty =
            DependencyProperty.Register("Target", typeof(object), typeof(BitmapSnapper), new PropertyMetadata(null, OnTargetChanged));

        private static void OnTargetChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((BitmapSnapper)obj).OnTargetChanged();
        }



        public DataTemplate TargetTemplate
        {
            get { return (DataTemplate)GetValue(TargetTemplateProperty); }
            set { SetValue(TargetTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TargetTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TargetTemplateProperty =
            DependencyProperty.Register("TargetTemplate", typeof(DataTemplate), typeof(BitmapSnapper), new PropertyMetadata(null, OnTargetChanged));

        protected override Size MeasureOverride(Size availableSize)
        {
            Size resultingSize = base.MeasureOverride(availableSize);
            _LastSize = availableSize;
            if (_AwaitingRefresh) Dispatcher.BeginInvoke(OnTargetChanged);
            return resultingSize;
        }

        private void OnTargetChanged()
        {
            if (this.Visibility == Visibility.Collapsed || _LastSize.Height <= 0 || _LastSize.Width <= 0)
            {
                _AwaitingRefresh = true;
                InvalidateMeasure();
                return;
            }
            object realTarget = Target;
            if (Target is WeakReference)
                realTarget = ((WeakReference)Target).IsAlive ? ((WeakReference)Target).Target : null;
            if (realTarget != null)
            {
                _AwaitingRefresh = false;
                var p = new Popup();
                var cp = new ContentPresenter { Content = realTarget, ContentTemplate = TargetTemplate };
                var cc = new ContentControl { Content = cp };
                p.Child = cc;
                p.Opacity = 0;
                p.Child.Opacity = 0;
                p.IsOpen = true;
                if (!(realTarget is UIElement))
                    p.UpdateLayout();
                cc.Measure(_LastSize);
                double width = Math.Max(this.ActualWidth, cp.DesiredSize.Width);
                double height = Math.Max(this.ActualHeight, cp.DesiredSize.Height);
                cp.Width = width;
                cp.Height = height;
                p.UpdateLayout();
                var wb = new WriteableBitmap((int)width, (int)height);
                wb.Render(cp, new TransformGroup());
                wb.Invalidate();
                cp.ClearValue(ContentPresenter.ContentProperty);
                Bitmap = wb;
                if (p != null) p.IsOpen = false;
                InvalidateMeasure();
                UpdateLayout();
            }
        }
    }
}
