﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Markup;
using SLaB.Utilities;

namespace SLaB.Controls.Phone
{
    [TemplatePart(Name = "CurrentContent", Type = typeof(ContentPresenter))]
    [TemplatePart(Name = "EnteringContent", Type = typeof(TransitionalControl))]
    [TemplatePart(Name = "LeavingContent", Type = typeof(TransitionalControl))]
    [StyleTypedProperty(Property = "EnteringStyle", StyleTargetType = typeof(TransitionalControl))]
    [StyleTypedProperty(Property = "LeavingStyle", StyleTargetType = typeof(TransitionalControl))]
    [ContentProperty("Content")]
    public class RichTransitionContentControl : Control
    {
        private ContentPresenter _CurrentContent;
        private TransitionalControl _EnteringContent;
        private TransitionalControl _LeavingContent;
        private int _TransitionWaitCount;
        public RichTransitionContentControl()
        {
            DefaultStyleKey = typeof(RichTransitionContentControl);
            this.Unloaded += (obj, args) =>
                {
                    //this._CurrentContent.Content = null;
                    //this._EnteringContent.Content = null;
                    //this._LeavingContent.Content = null;
                    //this.Content = null;
                };
        }



        public object Content
        {
            get { return (object)GetValue(ContentProperty); }
            set { SetValue(ContentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Content.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentProperty =
            DependencyProperty.Register("Content", typeof(object), typeof(RichTransitionContentControl), new PropertyMetadata(null, OnContentChanged));

        private static void OnContentChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((RichTransitionContentControl)obj).OnContentChanged(args.OldValue, args.NewValue);
        }


        public DataTemplate ContentTemplate
        {
            get { return (DataTemplate)GetValue(ContentTemplateProperty); }
            set { SetValue(ContentTemplateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentTemplateProperty =
            DependencyProperty.Register("ContentTemplate", typeof(DataTemplate), typeof(RichTransitionContentControl), new PropertyMetadata(null));





        public override void OnApplyTemplate()
        {
            if (_EnteringContent != null)
            {
                _EnteringContent.Content = null;
                _EnteringContent.TransitionCompleted -= EnteringContentTransitionCompleted;
            }
            if (_LeavingContent != null)
            {
                _LeavingContent.Content = null;
                _LeavingContent.TransitionCompleted -= LeavingContentTransitionCompleted;
            }
            if (_CurrentContent != null)
                _CurrentContent.Content = null;
            base.OnApplyTemplate();
            _CurrentContent = this.GetTemplateChild("CurrentContent") as ContentPresenter;
            _EnteringContent = this.GetTemplateChild("EnteringContent") as TransitionalControl;
            _LeavingContent = this.GetTemplateChild("LeavingContent") as TransitionalControl;
            _EnteringContent.TransitionCompleted += EnteringContentTransitionCompleted;
            _LeavingContent.TransitionCompleted += LeavingContentTransitionCompleted;
            _EnteringContent.Visibility = Visibility.Collapsed;
            _LeavingContent.Visibility = Visibility.Collapsed;
            _CurrentContent.Visibility = Visibility.Visible;
            Dispatcher.DelayUntil(() => _CurrentContent.Content = Content, () => IsUnparented(Content));
        }

        private bool IsUnparented(object content)
        {
            return !(content is UIElement) || VisualTreeHelper.GetParent((UIElement)content) == null || content == _CurrentContent.Content;
        }

        private int TransitionWaitCount
        {
            get
            {
                return _TransitionWaitCount;
            }
            set
            {
                _TransitionWaitCount = value;
                if (_TransitionWaitCount == 0)
                    TransitionWaitCountReachedZero();
            }
        }

        private void TransitionWaitCountReachedZero()
        {
            _EnteringContent.Content = null;
            _EnteringContent.Reset();
            _EnteringContent.Visibility = Visibility.Collapsed;
            _LeavingContent.Content = null;
            _LeavingContent.Reset();
            _LeavingContent.Visibility = Visibility.Collapsed;
            _CurrentContent.Content = Content;
            _CurrentContent.Visibility = Visibility.Visible;
        }

        private void LeavingContentTransitionCompleted(object sender, EventArgs e)
        {
            TransitionWaitCount--;
        }

        private void EnteringContentTransitionCompleted(object sender, EventArgs e)
        {
            TransitionWaitCount--;
        }

        protected virtual void OnContentChanged(object oldContent, object newContent)
        {
            if (_CurrentContent == null || _EnteringContent == null || _LeavingContent == null)
                return;
            Dispatcher.DelayUntil(() =>
                {
                    if (TransitionWaitCount > 0)
                        TransitionWaitCount = 0;
                    TransitionWaitCount = 2;
                    _CurrentContent.Content = null;
                    _CurrentContent.Visibility = Visibility.Collapsed;
                    _EnteringContent.Content = newContent;
                    _EnteringContent.ApplyTemplate();
                    _EnteringContent.Visibility = Visibility.Visible;
                    _LeavingContent.Content = WeaklyReferenceLeavingContent ? new WeakReference(oldContent) : oldContent;
                    _LeavingContent.ApplyTemplate();
                    _LeavingContent.Visibility = Visibility.Visible;
                    _LeavingContent.Transition();
                    _EnteringContent.Transition();
                }, () => IsUnparented(oldContent) && IsUnparented(newContent));
        }

        public Style EnteringStyle
        {
            get { return (Style)GetValue(EnteringStyleProperty); }
            set { SetValue(EnteringStyleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EnteringStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EnteringStyleProperty =
            DependencyProperty.Register("EnteringStyle", typeof(Style), typeof(RichTransitionContentControl), new PropertyMetadata(null));



        public Style LeavingStyle
        {
            get { return (Style)GetValue(LeavingStyleProperty); }
            set { SetValue(LeavingStyleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LeavingStyle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LeavingStyleProperty =
            DependencyProperty.Register("LeavingStyle", typeof(Style), typeof(RichTransitionContentControl), new PropertyMetadata(null));



        public bool WeaklyReferenceLeavingContent
        {
            get { return (bool)GetValue(WeaklyReferenceLeavingContentProperty); }
            set { SetValue(WeaklyReferenceLeavingContentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for WeaklyReferenceLeavingContent.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty WeaklyReferenceLeavingContentProperty =
            DependencyProperty.Register("WeaklyReferenceLeavingContent", typeof(bool), typeof(RichTransitionContentControl), new PropertyMetadata(true));


    }
}
