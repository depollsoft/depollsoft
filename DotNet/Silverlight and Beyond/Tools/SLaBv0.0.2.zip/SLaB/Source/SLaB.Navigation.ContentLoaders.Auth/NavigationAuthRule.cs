﻿using System;
using System.Security.Principal;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Markup;

namespace SLaB.Navigation.ContentLoaders.Auth
{
    /// <summary>
    /// Represents an authorization rule for the NavigationAuthorizer.
    /// </summary>
    [ContentProperty("Parts")]
    public class NavigationAuthRule : DependencyObject
    {
        /// <summary>
        /// Constructs a new NavigationAuthRule.
        /// </summary>
        public NavigationAuthRule()
        {
            Parts = new DependencyObjectCollection<INavigationAuthorizationRulePart>();
        }

        /// <summary>
        /// Specifies a regular expression to be used to match Uris being loaded.
        /// </summary>
        public string UriPattern
        {
            get { return (string)GetValue(UriProperty); }
            set { SetValue(UriProperty, value); }
        }

        /// <summary>
        /// Specifies a regular expression to be used to match Uris being loaded.
        /// </summary>
        public static readonly DependencyProperty UriProperty =
            DependencyProperty.Register("Uri", typeof(string), typeof(NavigationAuthRule), new PropertyMetadata(""));

        /// <summary>
        /// Specifies whether the regular expression will ignore case when checking for matches.  True by default.
        /// </summary>
        public bool IgnoreCase
        {
            get { return (bool)GetValue(IgnoreCaseProperty); }
            set { SetValue(IgnoreCaseProperty, value); }
        }

        /// <summary>
        /// Specifies whether the regular expression will ignore case when checking for matches.  True by default.
        /// </summary>
        public static readonly DependencyProperty IgnoreCaseProperty =
            DependencyProperty.Register("IgnoreCase", typeof(bool), typeof(NavigationAuthRule), new PropertyMetadata(true));

        /// <summary>
        /// Checks to see whether the given uri matches the UriPattern.
        /// </summary>
        /// <param name="uri">The uri being matched.</param>
        /// <returns>True if the Uri is a match for the regular expression pattern supplied as UriPattern.</returns>
        public bool Matches(Uri uri)
        {
            return new Regex(UriPattern, IgnoreCase ? RegexOptions.IgnoreCase : RegexOptions.None).IsMatch(uri.OriginalString);
        }

        /// <summary>
        /// The set of parts (e.g. Allow and Deny) that make up the authorization rule.
        /// </summary>
        public DependencyObjectCollection<INavigationAuthorizationRulePart> Parts
        {
            get { return (DependencyObjectCollection<INavigationAuthorizationRulePart>)GetValue(PartsProperty); }
            set { SetValue(PartsProperty, value); }
        }

        /// <summary>
        /// The set of parts (e.g. Allow and Deny) that make up the authorization rule.
        /// </summary>
        public static readonly DependencyProperty PartsProperty =
            DependencyProperty.Register("Parts", typeof(DependencyObjectCollection<INavigationAuthorizationRulePart>), typeof(NavigationAuthRule), new PropertyMetadata(null));

        /// <summary>
        /// Checks the principal against the parts of the rule and throws if the principal is unauthorized.
        /// </summary>
        /// <param name="principal">The principal whose credentials are being checked.</param>
        public void Check(IPrincipal principal)
        {
            if (Parts == null || Parts.Count == 0)
                return;
            foreach (var rule in Parts)
            {
                if (rule.IsAllowed(principal))
                    return;
                if (rule.IsDenied(principal))
                    throw new UnauthorizedAccessException(string.Format(ErrorStringPattern, this.UriPattern));
            }
            throw new UnauthorizedAccessException(string.Format(ErrorStringPattern, this.UriPattern));
        }

        private static readonly string ErrorStringPattern = "Cannot access due to rule for Uri Pattern: \"{0}\"";
    }
}
