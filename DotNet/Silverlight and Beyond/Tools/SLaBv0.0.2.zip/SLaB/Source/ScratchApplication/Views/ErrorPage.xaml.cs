﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using SLaB.Navigation.ContentLoaders.Error;

namespace ScratchApplication.Views
{
    public partial class ErrorPage : Page
    {
        public ErrorPage()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            this.errorInformation.Content = ErrorPageLoader.GetError(this);
            this.uriLink.NavigateUri = e.Uri;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(ErrorPageLoader.GetError(this).ToString());
        }

    }
}
