﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Silverlight.Testing;
using SLaB.Navigation.ContentLoaders.Event;
using System.Windows.Navigation;

namespace NavigationTests
{
    [TestClass]
    public class EventContentLoaderTests : SilverlightTest
    {
        [TestMethod]
        public void TestSynchronousEventContentLoader()
        {
            bool called = false;
            var loader = new SynchronousEventContentLoader();
            loader.Load += (targetUri, currentUri) =>
            {
                called = true;
                return new LoadResult(targetUri);
            };
            INavigationContentLoader ldr = loader;
            ldr.BeginLoad(new Uri("/Test", UriKind.Relative), null, (res) =>
            {
                Assert.IsTrue(res.CompletedSynchronously);
                Assert.IsTrue(called);
                Assert.AreEqual(ldr.EndLoad(res).RedirectUri, new Uri("/Test", UriKind.Relative));
            }, null);
        }
        [TestMethod]
        public void TestCanLoad()
        {
            bool called = false;
            var loader = new SynchronousEventContentLoader();
            loader.CanLoad += (target, current) =>
                {
                    called = true;
                    return false;
                };
            INavigationContentLoader ldr = loader;
            Assert.IsFalse(ldr.CanLoad(new Uri("/Test", UriKind.Relative), null));
            Assert.IsTrue(called);
        }
    }
}
