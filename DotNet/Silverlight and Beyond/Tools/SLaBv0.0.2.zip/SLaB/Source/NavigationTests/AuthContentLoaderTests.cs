﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SLaB.Navigation.ContentLoaders.Auth;
using System.Security.Principal;

namespace NavigationTests
{
    [TestClass]
    public class AuthContentLoaderTests : SilverlightTest
    {
        [TestMethod]
        public void TestAllow()
        {
            var tst = new Allow();
            var user = new UserShim { Name = "User", IsAuthenticated = true };
            Assert.IsFalse(tst.IsAllowed(user));
            tst.Roles = "somerole, role1";
            Assert.IsTrue(tst.IsAllowed(user));
            tst.Roles = "";
            Assert.IsFalse(tst.IsAllowed(user));
            tst.Users = "u1, User, u2";
            Assert.IsTrue(tst.IsAllowed(user));
            tst.Roles = "somerole, role1, role2";
            Assert.IsTrue(tst.IsAllowed(user));
            Assert.IsFalse(tst.IsDenied(user));
        }

        [TestMethod]
        public void TestDeny()
        {
            var tst = new Deny();
            var user = new UserShim { Name = "User", IsAuthenticated = true };
            Assert.IsFalse(tst.IsDenied(user));
            tst.Roles = "somerole, role1";
            Assert.IsTrue(tst.IsDenied(user));
            tst.Roles = "";
            Assert.IsFalse(tst.IsDenied(user));
            tst.Users = "u1, User, u2";
            Assert.IsTrue(tst.IsDenied(user));
            tst.Roles = "somerole, role1, role2";
            Assert.IsTrue(tst.IsDenied(user));
            Assert.IsFalse(tst.IsAllowed(user));
        }

        [TestMethod]
        public void TestNavigationAuthorizer()
        {
            var tst = new NavigationAuthorizer();
            tst.Rules.Add(new NavigationAuthRule
            {
                UriPattern = "^test1$",
                IgnoreCase = true,
                Parts = new DependencyObjectCollection<INavigationAuthorizationRulePart>
                {
                    new Allow{ Roles="somerole"}
                }
            });
            tst.Rules.Add(new NavigationAuthRule
            {
                UriPattern = "^test2$",
                IgnoreCase = true,
                Parts = new DependencyObjectCollection<INavigationAuthorizationRulePart>
                {
                    new Allow{ Roles="role1"}
                }
            });
            var user = new UserShim { Name = "User" };
            try
            {
                tst.CheckAuthorization(user, new Uri("test1", UriKind.Relative), null);
                Assert.Fail();
            }
            catch (UnauthorizedAccessException e)
            {
            }
            try
            {
                tst.CheckAuthorization(user, new Uri("test2", UriKind.Relative), null);
                Assert.Fail();
            }
            catch (UnauthorizedAccessException e)
            {
            }
            user.IsAuthenticated = true;
            try
            {
                tst.CheckAuthorization(user, new Uri("test1", UriKind.Relative), null);
                Assert.Fail();
            }
            catch (UnauthorizedAccessException e)
            {
            }
            try
            {
                tst.CheckAuthorization(user, new Uri("test2", UriKind.Relative), null);
            }
            catch (UnauthorizedAccessException e)
            {
                Assert.Fail();
            }
        }
    }

    internal class UserShim : IPrincipal, IIdentity
    {
        #region IPrincipal Members

        public IIdentity Identity
        {
            get { return this; }
        }

        public bool IsInRole(string role)
        {
            if (role.Equals("role1") || role.Equals("role2"))
                return true;
            return false;
        }

        #endregion

        #region IIdentity Members

        public string AuthenticationType
        {
            get { throw new NotImplementedException(); }
        }

        public bool IsAuthenticated
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        #endregion
    }

}
