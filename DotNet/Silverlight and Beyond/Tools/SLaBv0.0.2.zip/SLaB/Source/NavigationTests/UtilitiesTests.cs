﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Silverlight.Testing;
using SLaB.Navigation.ContentLoaders.Utilities;
using System.Threading;

namespace NavigationTests
{
    [TestClass]
    public class UtilitiesTests : SilverlightTest
    {
        private TestContentLoader redirectingContentLoader;
        private TestContentLoader pageReturningContentLoader;
        private Uri currentUri;
        private Uri targetUri;

        [TestInitialize]
        public void SetupTests()
        {
            pageReturningContentLoader = new TestContentLoader(true);
            redirectingContentLoader = new TestContentLoader(false);
            currentUri = new Uri("current", UriKind.Relative);
            targetUri = new Uri("target", UriKind.Relative);
        }

        [TestMethod]
        public void TestBeginLoad()
        {
            pageReturningContentLoader.BeginLoad(targetUri, currentUri, (result) => { }, null);
            Assert.AreEqual(targetUri, pageReturningContentLoader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, pageReturningContentLoader.LastLoader.CurrentUri);
        }
        [TestMethod]
        public void TestRedirectBeginLoad()
        {
            redirectingContentLoader.BeginLoad(targetUri, currentUri, (result) => { }, null);
            Assert.AreEqual(targetUri, redirectingContentLoader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, redirectingContentLoader.LastLoader.CurrentUri);
        }
        [TestMethod]
        [Asynchronous]
        public void TestLoad()
        {
            TestContentLoader loader = pageReturningContentLoader;
            IAsyncResult res = null;
            res = loader.BeginLoad(targetUri, currentUri, (result) =>
            {
                Assert.AreSame(res, result);
                var loadResult = loader.EndLoad(result);
                Assert.IsInstanceOfType(loadResult.LoadedContent, typeof(Page));
                Assert.AreEqual((loadResult.LoadedContent as Page).Tag, targetUri);
                this.TestComplete();
            }, null);
            Assert.IsFalse(!res.CompletedSynchronously && res.IsCompleted);
            Assert.AreEqual(targetUri, loader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, loader.LastLoader.CurrentUri);
        }
        [TestMethod]
        [Asynchronous]
        public void TestLoadRedirect()
        {
            TestContentLoader loader = redirectingContentLoader;
            IAsyncResult res = null;
            res = loader.BeginLoad(targetUri, currentUri, (result) =>
            {
                Assert.AreSame(res, result);
                var loadResult = loader.EndLoad(result);
                Assert.IsNull(loadResult.LoadedContent);
                Assert.AreEqual(loadResult.RedirectUri, new Uri("redirect", UriKind.Relative));
                this.TestComplete();
            }, null);
            Assert.IsFalse(!res.CompletedSynchronously && res.IsCompleted);
            Assert.AreEqual(targetUri, loader.LastLoader.TargetUri);
            Assert.AreEqual(currentUri, loader.LastLoader.CurrentUri);
        }
        [TestMethod]
        [Asynchronous]
        public void TestCancel()
        {
            TestContentLoader loader = redirectingContentLoader;
            IAsyncResult res = null;
            EnqueueCallback(() =>
                {
                    res = loader.BeginLoad(targetUri, currentUri, (result) =>
                    {
                        Assert.Fail("Callback should never be called when cancelled");
                    }, null);
                    Assert.IsFalse(!res.CompletedSynchronously && res.IsCompleted);
                },
                () =>
                {
                    loader.CancelLoad(res);
                });
            EnqueueDelay(100);
            EnqueueTestComplete();
        }
    }

    class TestLoader : LoaderBase
    {
        private bool returnsPage;
        public TestLoader(bool returnsPage)
        {
            this.returnsPage = returnsPage;
        }
        public override void Load(Uri targetUri, Uri currentUri)
        {
            TargetUri = targetUri;
            CurrentUri = currentUri;
            ThreadPool.QueueUserWorkItem((obj) =>
            {
                Thread.Sleep(100);
                if (returnsPage)
                    Complete(() => new Page() { Tag = targetUri });
                else
                    Complete(new Uri("redirect", UriKind.Relative));
            });
        }

        public override void Cancel()
        {
            Cancelled = true;
        }

        public Uri TargetUri { get; private set; }
        public Uri CurrentUri { get; private set; }
        public bool Cancelled { get; private set; }
    }

    class TestContentLoader : ContentLoaderBase
    {
        private bool returnsPage;
        public TestContentLoader(bool returnsPage)
        {
            this.returnsPage = returnsPage;
        }
        public TestLoader LastLoader { get; private set; }
        protected override LoaderBase CreateLoader()
        {
            LastLoader = new TestLoader(returnsPage);
            return LastLoader;
        }
    }
}
