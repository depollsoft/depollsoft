﻿using System;

namespace SLaB.Offline
{
    [Flags]
    public enum InstallMode
    {
        OutOfBrowser = 0x1,
        InBrowser = 0x2,
        Delayed = 0x4,
    }
}
