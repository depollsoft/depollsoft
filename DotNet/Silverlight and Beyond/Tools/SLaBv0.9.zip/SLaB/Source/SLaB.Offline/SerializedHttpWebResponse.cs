﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;

namespace SLaB.Offline
{
    public class SerializedHttpWebResponse : HttpWebResponse
    {
        private WebResponseData data;
        public SerializedHttpWebResponse(HttpWebResponse source)
        {
            data.ContentLength = source.ContentLength;
            data.ContentType = source.ContentType;
            data.Cookies.BackingStore.Add(source.Cookies);
            if (source.SupportsHeaders)
            {
                foreach (var header in source.Headers.AllKeys)
                    data.Headers[header] = source.Headers[header];
            }
            data.Method = source.Method;
            data.ResponseUri = source.ResponseUri;
            data.StatusCode = source.StatusCode;
            data.StatusDescription = source.StatusDescription;
        }

        private SerializedHttpWebResponse(WebResponseData data)
        {
            this.data = data;
        }

        public void Serialize(Stream outputStream)
        {
            StreamWriter writer = new StreamWriter(outputStream);
            writer.WriteLine(data.ContentLength);
            writer.WriteLine(data.ContentType);
            writer.WriteLine(data.Cookies.Count);
        }

        public static HttpWebResponse Deserialize(Stream inputStream)
        {

            return null;
        }

        public override CookieCollection Cookies
        {
            get { return data.Cookies.BackingStore; }
        }

        public override WebHeaderCollection Headers
        {
            get { return data.Headers; }
        }

        public override bool SupportsHeaders
        {
            get { return data.SupportsHeaders; }
        }

        public override string StatusDescription
        {
            get { return data.StatusDescription; }
        }

        public override HttpStatusCode StatusCode
        {
            get { return data.StatusCode; }
        }

        public override string Method
        {
            get { return data.Method; }
        }

        public override void Close()
        {
        }

        public override long ContentLength
        {
            get { return data.ContentLength; }
        }

        public override string ContentType
        {
            get { return data.ContentType; }
        }

        public override Stream GetResponseStream()
        {
            return new MemoryStream(data.Data, false);
        }

        public override Uri ResponseUri
        {
            get { return data.ResponseUri; }
        }

        private class WebResponseData
        {
            public WebResponseData()
            {
                Cookies = new SerializableCookieCollection();
                Headers = new WebHeaderCollection();
            }
            public long ContentLength { get; set; }
            public string ContentType { get; set; }
            public SerializableCookieCollection Cookies { get; set; }
            public byte[] Data { get; set; }
            public WebHeaderCollection Headers { get; set; }
            public string Method { get; set; }
            public Uri ResponseUri { get; set; }
            public HttpStatusCode StatusCode { get; set; }
            public string StatusDescription { get; set; }
            public bool SupportsHeaders { get; set; }
        }

        private class SerializableCookieCollection : IList<Cookie>
        {
            public SerializableCookieCollection()
            {
                BackingStore = new CookieCollection();
            }

            public CookieCollection BackingStore { get; set; }

            public int IndexOf(Cookie item)
            {
                throw new NotImplementedException();
            }

            public void Insert(int index, Cookie item)
            {
                throw new NotImplementedException();
            }

            public void RemoveAt(int index)
            {
                throw new NotImplementedException();
            }

            public Cookie this[int index]
            {
                get
                {
                    return BackingStore.Cast<Cookie>().ElementAt(index);
                }
                set
                {
                    throw new NotImplementedException();
                }
            }

            public void Add(Cookie item)
            {
                BackingStore.Add(item);
            }

            public void Clear()
            {
                throw new NotImplementedException();
            }

            public bool Contains(Cookie item)
            {
                throw new NotImplementedException();
            }

            public void CopyTo(Cookie[] array, int arrayIndex)
            {
                throw new NotImplementedException();
            }

            public int Count
            {
                get { return BackingStore.Count; }
            }

            public bool IsReadOnly
            {
                get { return false; }
            }

            public bool Remove(Cookie item)
            {
                throw new NotImplementedException();
            }

            public IEnumerator<Cookie> GetEnumerator()
            {
                return BackingStore.Cast<Cookie>().GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }
    }
}
