﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Net;
using System.Net.Browser;

namespace SLaB.Offline
{
    public class OfflinedFile
    {
        private bool isLoading;
        public Uri Uri { get; set; }
        public InstallMode InstallMode { get; set; }
        public UpdatePolicy UpdatePolicy { get; set; }
        private string _FileName;
        private string FileName
        {
            get
            {
                if (_FileName != null)
                    return _FileName;
                string fn = Uri.OriginalString;
                foreach (char ch in Path.GetInvalidPathChars())
                    fn.Replace("" + ch, "%SLaB%");
                _FileName = fn;
                return fn;
            }
        }
        private DateTime? LastChanged
        {
            get
            {
                IsolatedStorageFile f = IsolatedStorageFile.GetUserStoreForSite();
                if (!f.FileExists(FileName))
                    return null;
                return f.GetLastWriteTime(FileName).DateTime;
            }
        }

        private void CheckNeedsToDownload(Action<bool, WebResponse> callback, IWebRequestCreate fallbackCreator)
        {
            if (fallbackCreator == null)
                fallbackCreator = WebRequestCreator.BrowserHttp;
            HttpWebRequest hwr = (HttpWebRequest)fallbackCreator.Create(Uri);
            DateTime? lc = LastChanged;
            if (lc.HasValue)
                hwr.Headers[HttpRequestHeader.IfUnmodifiedSince] = lc.Value.ToString();
        }

        internal void Load(IWebRequestCreate fallbackCreator)
        {
            if (isLoading)
                return;
            if (fallbackCreator == null)
                fallbackCreator = WebRequestCreator.BrowserHttp;
        }

        internal event Action<Stream> FileLoaded;

    }
}
