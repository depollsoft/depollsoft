#pragma warning disable 1699

using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Markup;

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("David Poll")]
[assembly: AssemblyProduct("Silverlight and Beyond")]
[assembly: AssemblyCopyright("Copyright © David Poll 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.5.5.0")]

#if SLAB_PRIVATE
[assembly: AssemblyKeyFile("../SLaBKeyPrivate.snk")]
#else
[assembly: AssemblyKeyFile("../SLaBKey.snk")]
#endif

[assembly: XmlnsPrefix(Constants.XmlNamespace, "SLaB")]

internal static class Constants
{
    internal const string XmlNamespace = "http://www.davidpoll.com/SLaB";
}

#pragma warning restore 1699