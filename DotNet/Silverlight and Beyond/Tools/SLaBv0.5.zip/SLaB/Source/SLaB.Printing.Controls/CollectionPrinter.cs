﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Printing;
using SLaB.Utilities;

namespace SLaB.Printing.Controls
{
    /// <summary>
    /// A control that can be used to either preview or print a paginated collection.
    /// </summary>
    [ContentProperty("ItemsSource")]
    public class CollectionPrinter : ContentControl
    {
        private PrintDocument currentPrintDocument;
        private List<CollectionPrintContext> contexts;
        private List<CollectionPrinter> pagePrinters;
        private bool isRoot;
        private UIElement visualChild;
        private bool calculationComplete;
        private bool calculateInitialized;
        private int currentlyPrintingPage;
        private bool shouldEndPrinting;
        private bool progressivePrint;
        private object unloadLock = new object();

        /// <summary>
        /// Creates a CollectionPrinter.
        /// </summary>
        public CollectionPrinter()
        {
            if (DesignerProperties.IsInDesignTool)
                UiUtilities.InitializeExecuteOnUiThread();
            isRoot = true;
            this.DefaultStyleKey = typeof(CollectionPrinter);
            this.Loaded += new RoutedEventHandler(CollectionPrinter_Loaded);
            this.printCommand = new LambdaCommand<object>((param) => Print(), (param) => CanPrint);
            this.LayoutUpdated += CollectionPrinter_LayoutUpdated;
            this.Unloaded += new RoutedEventHandler(CollectionPrinter_Unloaded);
        }

        private void CollectionPrinter_Unloaded(object sender, RoutedEventArgs e)
        {
            lock (unloadLock)
            {
                contexts = null;
                pagePrinters = null;
            }
        }

        /// <summary>
        /// Called when a template is applied to the control.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            visualChild = (UIElement)VisualTreeHelper.GetChild(this, 0);
        }

        private CollectionPrinter(CollectionPrinter parent, CollectionPrintContext context)
        {
            if (DesignerProperties.IsInDesignTool)
                UiUtilities.InitializeExecuteOnUiThread();
            isRoot = false;
            this.printCommand = new LambdaCommand<object>((param) => Print(), (param) => CanPrint);
            this.DefaultStyleKey = typeof(CollectionPrinter);
            this.Style = parent.Style;
            this.CurrentPrintContext = context;
            this.CurrentPageIndex = context.CurrentPageIndex;
            this.HeaderTemplate = parent.HeaderTemplate;
            this.FooterTemplate = parent.FooterTemplate;
            this.IgnoreHorizontalOverflow = parent.IgnoreHorizontalOverflow;
            //this.ItemsSource = parent.ItemsSource;
            this.ItemTemplate = parent.ItemTemplate;
            this.ItemsPanel = parent.ItemsPanel;
            this.Content = parent.Content;
            this.ContentTemplate = parent.ContentTemplate;
            this.BodyTemplate = parent.BodyTemplate;
            this.MaximumItemsPerPage = parent.MaximumItemsPerPage;
        }

        private void CollectionPrinter_Loaded(object sender, RoutedEventArgs e)
        {
            //if (!DesignerProperties.GetIsInDesignMode(this) && (this.Parent != null || !(this.Parent is Popup)))
            //    throw new Exception("Cannot place CollectionPrinter in the visual tree");
            OnRenderSpecificPropertyChanged();
        }

        private void CollectionPrinter_LayoutUpdated(object sender, EventArgs e)
        {
            //if (DesignerProperties.GetIsInDesignMode(this))
            //    OnRenderSpecificPropertyChanged();
        }

        private LambdaCommand<object> printCommand;
        /// <summary>
        /// A command that will cause printing to occur when executed.
        /// </summary>
        public ICommand PrintCommand
        {
            get
            {
                return printCommand;
            }
        }

        /// <summary>
        /// Prints a document from end to end.
        /// </summary>
        public void Print()
        {
            PrintDocument pd = new PrintDocument();
            pd.BeginPrint += Print_BeginPrint;
            pd.EndPrint += Print_EndPrint;
            shouldEndPrinting = true;
            Print(pd);
            pd.Print(this.PrintDocumentName);
        }

        private void Print_EndPrint(object sender, EndPrintEventArgs e)
        {
            currentPrintDocument = null;
            currentlyPrintingPage = 0;
            CurrentlySpoolingPage = 0;
            CurrentlyPrintingPage = 0;
            IsPrinting = false;
            if (e.Error != null)
            {
                throw new Exception("Printing failed", e.Error);
            }
            shouldEndPrinting = false;
        }

        private void Print_BeginPrint(object sender, BeginPrintEventArgs e)
        {
        }

        /// <summary>
        /// Prints the collection into an existing PrintDocument.  The CollectionPrinter will never set
        /// HasMorePages to be true -- that is left to the original creator of the PrintDocument.
        /// </summary>
        /// <param name="document"></param>
        public void Print(PrintDocument document)
        {
            if (currentPrintDocument != null)
                throw new Exception("Cannot print two things at once");
            currentPrintDocument = document;
            calculateInitialized = false;
            currentlyPrintingPage = 0;
            CurrentlySpoolingPage = 0;
            CurrentlyPrintingPage = 0;
            progressivePrint = false;
            IsPrinting = true;
            document.PrintPage += PrintDoc_PrintPage;
        }

        private int retryCount = 0;
        private void PrintDoc_PrintPage(object sender, PrintPageEventArgs e)
        {
            if (retryCount >= 7)
                progressivePrint = true;
            if (!calculateInitialized)
            {
                calculationComplete = false;
                Calculate(e.PrintableArea, e.PageMargins);
                calculateInitialized = true;
                retryCount = 0;
            }
            else if (!calculationComplete && (!progressivePrint || currentlyPrintingPage >= pagePrinters.Count) || retryCount <= 3)
            {
                CurrentlyPrintingPage = currentlyPrintingPage;
                e.PageVisual = null;
                e.HasMorePages = true;
                retryCount++;
            }
            else
            {
                e.PageVisual = this.pagePrinters[currentlyPrintingPage];
                e.PageVisual.Measure(e.PrintableArea);
                e.PageVisual.UpdateLayout();
                e.HasMorePages = true;
                currentlyPrintingPage++;
                CurrentlyPrintingPage = currentlyPrintingPage;
                if (calculationComplete && currentlyPrintingPage >= pagePrinters.Count)
                {
                    if (shouldEndPrinting)
                        e.HasMorePages = false;
                    else
                    {
                        currentPrintDocument = null;
                        currentlyPrintingPage = 0;
                        CurrentlySpoolingPage = 0;
                        CurrentlyPrintingPage = 0;
                        contexts = null;
                        pagePrinters = null;
                    }
                    IsPrinting = false;
                    ((PrintDocument)sender).PrintPage -= PrintDoc_PrintPage;
                }
                retryCount = 0;
            }
        }

        private void DriveAnimationsToCompletion(FrameworkElement element)
        {
            if (element == null)
                return;
            var groups = VisualStateManager.GetVisualStateGroups(element);
            foreach (VisualStateGroup group in groups)
            {
                foreach (Storyboard board in group.Transitions.Cast<VisualTransition>().Select((trans) => trans.Storyboard)
                    .Concat(group.States.Cast<VisualState>().Select((state) => state.Storyboard))
                    .Where((board) => board.GetCurrentState() != ClockState.Stopped))
                {
                    board.SkipToFill();
                }
            }
            foreach (FrameworkElement child in Enumerable.Range(0, VisualTreeHelper.GetChildrenCount(element)).Select((index) => VisualTreeHelper.GetChild(element, index)).OfType<FrameworkElement>())
                DriveAnimationsToCompletion(child);
        }

        private void CalculateChild(object signal)
        {
            Debug.Assert(!this.isRoot);
            Popup popup = new Popup();
            Grid layoutContainer;
            popup.Child = layoutContainer = new Grid();
            layoutContainer.Children.Add(this);
            popup.Opacity = 0;
            layoutContainer.Opacity = 0;
            layoutContainer.IsHitTestVisible = false;
            popup.IsHitTestVisible = false;
            Width = popup.Width = CurrentPrintContext.PrintableArea.Width;
            Height = popup.Height = CurrentPrintContext.PrintableArea.Height;
            var items = (ItemsSource ?? new object[0]).Cast<object>().Skip(CurrentPrintContext.FirstItemIndex).ToArray();
            ObservableCollection<object> pageItems = new ObservableCollection<object>();
            CurrentPrintContext.CurrentItems = pageItems;
            Dispatcher.DelayUntil(() =>
                {
                    try
                    {
                        CurrentPrintContext.IsLastPage = false;
                        int itemsAdded = 0;
                        do
                        {
                            if (itemsAdded >= items.Length || (MaximumItemsPerPage != -1 && itemsAdded >= MaximumItemsPerPage))
                                break;
                            pageItems.Add(items[itemsAdded++]);
                            CurrentPrintContext.LastItemIndex = CurrentPrintContext.FirstItemIndex + itemsAdded - 1;
                            if (itemsAdded == items.Length)
                                CurrentPrintContext.IsLastPage = true;
                            CurrentPrintContext.NotifyPropertiesChanged();
                            //popup.UpdateLayout();
                            visualChild.Measure(CurrentPrintContext.PrintableArea);
                        }
                        while (CheckWidth() && CheckHeight());
                        while (itemsAdded != 1 && !(CheckExpandedWidth() && CheckExpandedHeight() && CheckExpandedWidthHeight()))
                        {
                            pageItems.RemoveAt(pageItems.Count - 1);
                            itemsAdded--;
                            CurrentPrintContext.LastItemIndex = CurrentPrintContext.FirstItemIndex + itemsAdded - 1;
                            CurrentPrintContext.IsLastPage = false;
                            CurrentPrintContext.NotifyPropertiesChanged();
                        }
                        Dispatcher.BeginInvoke(() =>
                            {
                                DriveAnimationsToCompletion(popup);
                                Dispatcher.BeginInvoke(() =>
                                    {
                                        popup.IsOpen = false;
                                        popup.Child = null;
                                        layoutContainer.Children.Clear();
                                        lock (signal) Monitor.Pulse(signal);
                                    });
                            });
                    }
                    catch (Exception e)
                    {
                        MessageBox.Show(e.ToString());
                    }
                }, () => visualChild != null);
            popup.IsOpen = true;
        }

        private bool CheckExpandedWidthHeight()
        {
            if (CheckHeight() || CheckWidth())
                return true;
            visualChild.Measure(new Size(CurrentPrintContext.PrintableArea.Width + 1, CurrentPrintContext.PrintableArea.Height + 1));
            return CheckSize();
        }

        private bool CheckExpandedHeight()
        {
            if (CheckHeight())
                return true;
            visualChild.Measure(new Size(CurrentPrintContext.PrintableArea.Width, CurrentPrintContext.PrintableArea.Height + 1));
            return CheckHeight();
        }

        private bool CheckExpandedWidth()
        {
            if (CheckWidth())
                return true;
            visualChild.Measure(new Size(CurrentPrintContext.PrintableArea.Width + 1, CurrentPrintContext.PrintableArea.Height));
            return CheckWidth();
        }

        private bool CheckSize()
        {
            return CheckHeight() && CheckWidth();
        }

        private bool CheckHeight()
        {
            return visualChild.DesiredSize.Height < CurrentPrintContext.PrintableArea.Height;
        }

        private bool CheckWidth()
        {
            return IgnoreHorizontalOverflow || visualChild.DesiredSize.Width < CurrentPrintContext.PrintableArea.Width;
        }

        private bool isCalculating;
        private object calcLock = new object();

        private void Calculate(Size? printableArea = null, Thickness? pageMargins = null)
        {
            bool wasExplicit = printableArea != null && pageMargins != null;
            if (!wasExplicit && this.Parent == null)
                return;
            object signal = new object();
            if (double.IsNaN(this.Width) || double.IsNaN(this.Height))
                return;
            if (printableArea == null)
                printableArea = new Size(this.Width, this.Height);
            if (pageMargins == null)
                pageMargins = new Thickness(100);
            var items = ItemsSource ?? new object[0];
            Debug.Assert(this.isRoot);
            if (!isCalculating || wasExplicit)
            {
                Dispatcher.DelayUntil(() =>
                    {
                        isCalculating = true;
                        ThreadPool.QueueUserWorkItem((args) =>
                        {
                            try
                            {
                                lock (calcLock)
                                {
                                    int itemsSoFar = 0;
                                    int currentPage = 0;
                                    contexts = new List<CollectionPrintContext>();
                                    pagePrinters = new List<CollectionPrinter>();
                                    while (itemsSoFar == 0 || itemsSoFar < items.Cast<object>().Count())
                                    {
                                        var context = new CollectionPrintContext(this);
                                        context.IsFirstPage = currentPage == 0;
                                        context.CurrentPageIndex = currentPage;
                                        context.FirstItemIndex = itemsSoFar;
                                        context.PrintableArea = printableArea.Value;
                                        context.PageMargins = pageMargins.Value;
                                        CollectionPrinter printer = null;
                                        UiUtilities.ExecuteOnUiThread(() =>
                                            {
                                                if (wasExplicit)
                                                {
                                                    if (currentPrintDocument != null)
                                                        CurrentlySpoolingPage = context.CurrentPage;
                                                    else
                                                        CurrentlySpoolingPage = 0;
                                                }
                                                printer = new CollectionPrinter(this, context);
                                                printer.ItemsSource = items;
                                                printer.CalculateChild(signal);
                                                lock (unloadLock)
                                                {
                                                    if (this.CurrentPageIndex < currentPage && contexts != null)
                                                        this.CurrentPrintContext = contexts[this.CurrentPageIndex];
                                                }
                                            });
                                        lock (signal) Monitor.Wait(signal);
                                        itemsSoFar += context.CurrentItems.Cast<object>().Count();
                                        currentPage++;
                                        if (itemsSoFar == items.Cast<object>().Count() && progressivePrint)
                                            calculationComplete = true;
                                        lock (unloadLock)
                                        {
                                            if (contexts != null)
                                                contexts.Add(context);
                                            if (pagePrinters != null)
                                                pagePrinters.Add(printer);
                                        }
                                        if (itemsSoFar == 0)
                                            break;
                                    }
                                    UiUtilities.ExecuteOnUiThread(() =>
                                        {
                                            lock (unloadLock)
                                            {
                                                if (!progressivePrint && contexts != null)
                                                    foreach (var context in contexts)
                                                        context.PageCount = currentPage;
                                            }
                                            if (wasExplicit)
                                            {
                                                CurrentlySpoolingPage = 0;
                                                if (currentPrintDocument != null)
                                                    CurrentlyPrintingPage = 1;
                                            }
                                        });
                                    isCalculating = false;
                                    calculationComplete = true;
                                    UiUtilities.ExecuteOnUiThread(() =>
                                    {
                                        if (contexts != null)
                                            this.CurrentPrintContext = contexts[Math.Min(this.CurrentPageIndex, contexts.Count - 1)];
                                    });
                                }
                            }
                            catch (Exception e)
                            {
                                UiUtilities.ExecuteOnUiThread(() => MessageBox.Show(e.ToString()));
                            }
                        });
                    }, () => !isCalculating);
            }
        }

        private void OnRenderSpecificPropertyChanged()
        {
            if (this.isRoot)
                Dispatcher.BeginInvoke(() => Calculate());
        }

        /// <summary>
        /// Gets or sets the index of the page being displayed by the control.
        /// </summary>
        [Category("Common Properties")]
        public int CurrentPageIndex
        {
            get { return (int)GetValue(CurrentPageIndexProperty); }
            set { SetValue(CurrentPageIndexProperty, value); }
        }

        /// <summary>
        /// Gets or sets the index of the page being displayed by the control.
        /// </summary>
        public static readonly DependencyProperty CurrentPageIndexProperty =
            DependencyProperty.Register("CurrentPageIndex", typeof(int), typeof(CollectionPrinter), new PropertyMetadata(default(int), OnCurrentPageIndexChanged));

        private static void OnCurrentPageIndexChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnCurrentPageIndexChanged((int)args.OldValue, (int)args.NewValue);
        }

        private void OnCurrentPageIndexChanged(int oldValue, int newValue)
        {
            if (this.contexts == null)
                OnRenderSpecificPropertyChanged();
            else
                this.CurrentPrintContext = contexts[this.CurrentPageIndex < contexts.Count ? this.CurrentPageIndex : 0];
        }

        /// <summary>
        /// Gets the CollectionPrintContext for the page being printed or displayed.
        /// </summary>
        public CollectionPrintContext CurrentPrintContext
        {
            get { return (CollectionPrintContext)GetValue(CurrentPrintContextProperty); }
            private set { SetValue(CurrentPrintContextProperty, value); }
        }

        /// <summary>
        /// Gets the CollectionPrintContext for the page being printed or displayed.
        /// </summary>
        public static readonly DependencyProperty CurrentPrintContextProperty =
            DependencyProperty.Register("CurrentPrintContext", typeof(CollectionPrintContext), typeof(CollectionPrinter), new PropertyMetadata(default(CollectionPrintContext), OnCurrentPrintContextChanged));

        private static void OnCurrentPrintContextChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnCurrentPrintContextChanged((CollectionPrintContext)args.OldValue, (CollectionPrintContext)args.NewValue);
        }

        private void OnCurrentPrintContextChanged(CollectionPrintContext oldValue, CollectionPrintContext newValue)
        {
        }

        /// <summary>
        /// Gets whether the control is ready for printing.
        /// </summary>
        public bool CanPrint
        {
            get { return (bool)GetValue(CanPrintProperty); }
            private set { SetValue(CanPrintProperty, value); }
        }

        /// <summary>
        /// Gets whether the control is ready for printing.
        /// </summary>
        public static readonly DependencyProperty CanPrintProperty =
            DependencyProperty.Register("CanPrint", typeof(bool), typeof(CollectionPrinter), new PropertyMetadata(default(bool), OnCanPrintChanged));

        private static void OnCanPrintChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnCanPrintChanged((bool)args.OldValue, (bool)args.NewValue);
        }

        private void OnCanPrintChanged(bool oldValue, bool newValue)
        {
            printCommand.RefreshCanExecute();
        }

        /// <summary>
        /// Gets or sets the name of the document to be printed.
        /// </summary>
        [Category("Common Properties")]
        public string PrintDocumentName
        {
            get { return (string)GetValue(PrintDocumentNameProperty); }
            set { SetValue(PrintDocumentNameProperty, value); }
        }

        /// <summary>
        /// Gets or sets the name of the document to be printed.
        /// </summary>
        public static readonly DependencyProperty PrintDocumentNameProperty =
            DependencyProperty.Register("PrintDocumentName", typeof(string), typeof(CollectionPrinter), new PropertyMetadata("Silverlight Document", OnPrintDocumentNameChanged));

        private static void OnPrintDocumentNameChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnPrintDocumentNameChanged((string)args.OldValue, (string)args.NewValue);
        }

        private void OnPrintDocumentNameChanged(string oldValue, string newValue)
        {
        }

        /// <summary>
        /// Gets or sets the template that will be used for the header of each page.
        /// </summary>
        [Category("Common Properties")]
        public DataTemplate HeaderTemplate
        {
            get { return (DataTemplate)GetValue(HeaderTemplateProperty); }
            set { SetValue(HeaderTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template that will be used for the header of each page.
        /// </summary>
        public static readonly DependencyProperty HeaderTemplateProperty =
            DependencyProperty.Register("HeaderTemplate", typeof(DataTemplate), typeof(CollectionPrinter), new PropertyMetadata(default(DataTemplate), OnHeaderTemplateChanged));

        private static void OnHeaderTemplateChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnHeaderTemplateChanged((DataTemplate)args.OldValue, (DataTemplate)args.NewValue);
        }

        private void OnHeaderTemplateChanged(DataTemplate oldValue, DataTemplate newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets the template that will be used for the footer of each page.
        /// </summary>
        [Category("Common Properties")]
        public DataTemplate FooterTemplate
        {
            get { return (DataTemplate)GetValue(FooterTemplateProperty); }
            set { SetValue(FooterTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template that will be used for the footer of each page.
        /// </summary>
        public static readonly DependencyProperty FooterTemplateProperty =
            DependencyProperty.Register("FooterTemplate", typeof(DataTemplate), typeof(CollectionPrinter), new PropertyMetadata(default(DataTemplate), OnFooterTemplateChanged));

        private static void OnFooterTemplateChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnFooterTemplateChanged((DataTemplate)args.OldValue, (DataTemplate)args.NewValue);
        }

        private void OnFooterTemplateChanged(DataTemplate oldValue, DataTemplate newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets the template for each item (used in the default ItemsControl-based template for
        /// the CollectionPrinter).
        /// </summary>
        [Category("Common Properties")]
        public DataTemplate ItemTemplate
        {
            get { return (DataTemplate)GetValue(ItemTemplateProperty); }
            set { SetValue(ItemTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template for each item (used in the default ItemsControl-based template for
        /// the CollectionPrinter).
        /// </summary>
        public static readonly DependencyProperty ItemTemplateProperty =
            DependencyProperty.Register("ItemTemplate", typeof(DataTemplate), typeof(CollectionPrinter), new PropertyMetadata(default(DataTemplate), OnItemTemplateChanged));

        private static void OnItemTemplateChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnItemTemplateChanged((DataTemplate)args.OldValue, (DataTemplate)args.NewValue);
        }

        private void OnItemTemplateChanged(DataTemplate oldValue, DataTemplate newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets the collection to be printed.
        /// </summary>
        [Category("Common Properties")]
        public IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        /// <summary>
        /// Gets or sets the collection to be printed.
        /// </summary>
        [Category("Common Properties")]
        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(CollectionPrinter), new PropertyMetadata(default(IEnumerable), OnItemsSourceChanged));

        private static void OnItemsSourceChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnItemsSourceChanged((IEnumerable)args.OldValue, (IEnumerable)args.NewValue);
        }

        private void OnItemsSourceChanged(IEnumerable oldValue, IEnumerable newValue)
        {
            if (oldValue != null && oldValue is INotifyCollectionChanged)
                ((INotifyCollectionChanged)oldValue).CollectionChanged -= CollectionPrinter_CollectionChanged;
            if (newValue != null && newValue is INotifyCollectionChanged)
                ((INotifyCollectionChanged)newValue).CollectionChanged += CollectionPrinter_CollectionChanged;
            OnRenderSpecificPropertyChanged();
            UpdateCanPrint();
        }

        private void CollectionPrinter_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets whether the CollectionPrinter should ignore overflow in the horizontal direction when paginating.
        /// </summary>
        [Category("Common Properties")]
        public bool IgnoreHorizontalOverflow
        {
            get { return (bool)GetValue(IgnoreHorizontalOverflowProperty); }
            set { SetValue(IgnoreHorizontalOverflowProperty, value); }
        }

        /// <summary>
        /// Gets or sets whether the CollectionPrinter should ignore overflow in the horizontal direction when paginating.
        /// </summary>
        public static readonly DependencyProperty IgnoreHorizontalOverflowProperty =
            DependencyProperty.Register("IgnoreHorizontalOverflow", typeof(bool), typeof(CollectionPrinter), new PropertyMetadata(default(bool), OnIgnoreHorizontalOverflowChanged));

        private static void OnIgnoreHorizontalOverflowChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnIgnoreHorizontalOverflowChanged((bool)args.OldValue, (bool)args.NewValue);
        }

        private void OnIgnoreHorizontalOverflowChanged(bool oldValue, bool newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets the ItemsPanelTemplate for the ItemsControl-based default template for printing.
        /// </summary>
        public ItemsPanelTemplate ItemsPanel
        {
            get { return (ItemsPanelTemplate)GetValue(ItemsPanelProperty); }
            set { SetValue(ItemsPanelProperty, value); }
        }

        /// <summary>
        /// Gets or sets the ItemsPanelTemplate for the ItemsControl-based default template for printing.
        /// </summary>
        public static readonly DependencyProperty ItemsPanelProperty =
            DependencyProperty.Register("ItemsPanel", typeof(ItemsPanelTemplate), typeof(CollectionPrinter), new PropertyMetadata(default(ItemsPanelTemplate), OnItemsPanelChanged));

        private static void OnItemsPanelChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnItemsPanelChanged((ItemsPanelTemplate)args.OldValue, (ItemsPanelTemplate)args.NewValue);
        }

        private void OnItemsPanelChanged(ItemsPanelTemplate oldValue, ItemsPanelTemplate newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets the template for the background of each page.
        /// </summary>
        public DataTemplate PageBackgroundTemplate
        {
            get { return (DataTemplate)GetValue(PageBackgroundTemplateProperty); }
            set { SetValue(PageBackgroundTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template for the background of each page.
        /// </summary>
        public static readonly DependencyProperty PageBackgroundTemplateProperty =
            DependencyProperty.Register("PageBackgroundTemplate", typeof(DataTemplate), typeof(CollectionPrinter), new PropertyMetadata(default(DataTemplate), OnPageBackgroundTemplateChanged));

        private static void OnPageBackgroundTemplateChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnPageBackgroundTemplateChanged((DataTemplate)args.OldValue, (DataTemplate)args.NewValue);
        }

        private void OnPageBackgroundTemplateChanged(DataTemplate oldValue, DataTemplate newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        //TODO: Decide how to handle the Content property.
        //protected override void OnContentChanged(object oldContent, object newContent)
        //{
        //    base.OnContentChanged(oldContent, newContent);
        //    UpdateCanPrint();
        //}

        private void UpdateCanPrint()
        {
            CanPrint = ItemsSource != null || Content != null;
        }

        /// <summary>
        /// Gets the one-based index of the page being spooled.
        /// </summary>
        public int CurrentlySpoolingPage
        {
            get { return (int)GetValue(CurrentlySpoolingPageProperty); }
            private set { SetValue(CurrentlySpoolingPageProperty, value); }
        }

        /// <summary>
        /// Gets the one-based index of the page being spooled.
        /// </summary>
        public static readonly DependencyProperty CurrentlySpoolingPageProperty =
            DependencyProperty.Register("CurrentlySpoolingPage", typeof(int), typeof(CollectionPrinter), new PropertyMetadata(0));

        /// <summary>
        /// Gets the one-based index of the page being printed.
        /// </summary>
        public int CurrentlyPrintingPage
        {
            get { return (int)GetValue(CurrentlyPrintingPageProperty); }
            private set { SetValue(CurrentlyPrintingPageProperty, value); }
        }

        /// <summary>
        /// Gets the one-based index of the page being printed.
        /// </summary>
        public static readonly DependencyProperty CurrentlyPrintingPageProperty =
            DependencyProperty.Register("CurrentlyPrintingPage", typeof(int), typeof(CollectionPrinter), new PropertyMetadata(0));

        /// <summary>
        /// Gets whether the CollectionPrinter is currently printing.
        /// </summary>
        public bool IsPrinting
        {
            get { return (bool)GetValue(IsPrintingProperty); }
            private set { SetValue(IsPrintingProperty, value); }
        }

        /// <summary>
        /// Gets whether the CollectionPrinter is currently printing.
        /// </summary>
        public static readonly DependencyProperty IsPrintingProperty =
            DependencyProperty.Register("IsPrinting", typeof(bool), typeof(CollectionPrinter), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets the template for the body of each page.  This usually contains some sort of collection-displaying
        /// control that grows as more items are added to the CurrentPrintContext.CurrentItems collection.
        /// </summary>
        [Category("Common Properties")]
        public DataTemplate BodyTemplate
        {
            get { return (DataTemplate)GetValue(BodyTemplateProperty); }
            set { SetValue(BodyTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the template for the body of each page.  This usually contains some sort of collection-displaying
        /// control that grows as more items are added to the CurrentPrintContext.CurrentItems collection.
        /// </summary>
        public static readonly DependencyProperty BodyTemplateProperty =
            DependencyProperty.Register("BodyTemplate", typeof(DataTemplate), typeof(CollectionPrinter), new PropertyMetadata(default(DataTemplate), OnBodyTemplateChanged));

        private static void OnBodyTemplateChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnBodyTemplateChanged((DataTemplate)args.OldValue, (DataTemplate)args.NewValue);
        }

        private void OnBodyTemplateChanged(DataTemplate oldValue, DataTemplate newValue)
        {
            OnRenderSpecificPropertyChanged();
        }

        /// <summary>
        /// Gets or sets the maximum number of items to place on a page.  Set this value to -1 to
        /// print as many items as possible on the page.
        /// </summary>
        [Category("Common Properties")]
        public int MaximumItemsPerPage
        {
            get { return (int)GetValue(MaximumItemsPerPageProperty); }
            set { SetValue(MaximumItemsPerPageProperty, value); }
        }

        /// <summary>
        /// Gets or sets the maximum number of items to place on a page.  Set this value to -1 to
        /// print as many items as possible on the page.
        /// </summary>
        public static readonly DependencyProperty MaximumItemsPerPageProperty =
            DependencyProperty.Register("MaximumItemsPerPage", typeof(int), typeof(CollectionPrinter), new PropertyMetadata(-1, OnMaximumItemsPerPageChanged));

        private static void OnMaximumItemsPerPageChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((CollectionPrinter)obj).OnMaximumItemsPerPageChanged((int)args.OldValue, (int)args.NewValue);
        }

        private void OnMaximumItemsPerPageChanged(int oldValue, int newValue)
        {
            if (newValue < 1 && newValue != -1)
                throw new ArgumentException();
        }
    }
}
