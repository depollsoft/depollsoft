﻿using System.Windows.Controls;
using System.Windows.Navigation;
using System.Windows;
using System.Collections.Generic;
using SLaB.Utilities.Xaml.Collections;

namespace ScratchApplication
{
    public partial class About : Page
    {
        public About()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

    }
}