﻿using System.Windows.Controls;
using System.Windows.Navigation;
using SLaB.Navigation.ContentLoaders.MEF;

namespace ScratchApplication
{
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }
    }
}