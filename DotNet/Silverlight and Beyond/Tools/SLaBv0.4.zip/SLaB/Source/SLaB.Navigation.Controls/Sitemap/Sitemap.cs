﻿using System.Windows;
using System.Windows.Markup;
using System.Collections.Generic;

namespace SLaB.Navigation.Controls.Sitemap
{
    /// <summary>
    /// Represents a Sitemap.
    /// </summary>
    [ContentProperty("Nodes")]
    public class Sitemap : DependencyObject, ISitemap
    {
        /// <summary>
        /// Creates a new Sitemap.
        /// </summary>
        public Sitemap()
        {
            Nodes = new DependencyObjectCollection<ISitemapNode>();
        }

        IEnumerable<ISitemapNode> ISitemap.Nodes { get { return this.Nodes; } }

        /// <summary>
        /// Gets the list of child nodes for this Sitemap.
        /// </summary>
        public DependencyObjectCollection<ISitemapNode> Nodes
        {
            get { return (DependencyObjectCollection<ISitemapNode>)GetValue(NodesProperty); }
            private set { SetValue(NodesProperty, value); }
        }

        /// <summary>
        /// Gets the list of child nodes for this Sitemap.
        /// </summary>
        private static readonly DependencyProperty NodesProperty =
            DependencyProperty.Register("Nodes", typeof(DependencyObjectCollection<ISitemapNode>), typeof(Sitemap), new PropertyMetadata(null));

        /// <summary>
        /// Gets or sets the title of this sitemap.
        /// </summary>
        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the title of this sitemap.
        /// </summary>
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(Sitemap), new PropertyMetadata(""));

        /// <summary>
        /// Gets or sets the description for this Sitemap.
        /// </summary>
        public string Description
        {
            get { return (string)GetValue(DescriptionProperty); }
            set { SetValue(DescriptionProperty, value); }
        }

        /// <summary>
        /// Gets or sets the description for this Sitemap.
        /// </summary>
        public static readonly DependencyProperty DescriptionProperty =
            DependencyProperty.Register("Description", typeof(string), typeof(Sitemap), new PropertyMetadata(null));
    }
}
