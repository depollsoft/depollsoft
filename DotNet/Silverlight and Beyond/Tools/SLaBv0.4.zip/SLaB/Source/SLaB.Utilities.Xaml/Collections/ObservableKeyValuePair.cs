﻿using System.ComponentModel;
using System.Text;

namespace SLaB.Utilities.Xaml.Collections
{
    public sealed class ObservableKeyValuePair<TKey, TValue> : INotifyPropertyChanged
    {
        public ObservableKeyValuePair(TKey key)
        {
            this.key = key;
        }
        private TKey key;
        private TValue value;
        public TKey Key
        {
            get
            {
                return key;
            }
        }
        public TValue Value
        {
            get
            {
                return value;
            }
            set
            {
                if (!object.Equals(this.value, value))
                {
                    this.value = value;
                    OnPropertyChanged("Value");
                }
            }
        }
        private void OnPropertyChanged(string propertyName)
        {
            var pc = PropertyChanged;
            if (pc != null)
                pc(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append('[');
            if (this.Key != null)
                builder.Append(this.Key.ToString());
            builder.Append(", ");
            if (this.Value != null)
                builder.Append(this.Value.ToString());
            builder.Append(']');
            return builder.ToString();
        }

    }
}
