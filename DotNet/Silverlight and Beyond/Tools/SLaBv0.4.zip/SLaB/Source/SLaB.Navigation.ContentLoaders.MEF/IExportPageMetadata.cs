﻿
namespace SLaB.Navigation.ContentLoaders.MEF
{
    /// <summary>
    /// Defines Page Export metadata.
    /// </summary>
    public interface IExportPageMetadata
    {
        string NavigateUri { get; }
    }
}
