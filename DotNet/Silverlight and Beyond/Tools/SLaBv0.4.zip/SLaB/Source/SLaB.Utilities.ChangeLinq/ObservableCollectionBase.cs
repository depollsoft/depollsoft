﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;

namespace SLaB.Utilities.ChangeLinq
{
    internal class ObservableCollectionBase<T> : IEnumerable<T>, INotifyCollectionChanged, INotifyPropertyChanged, ICollection
    {
        public ObservableCollectionBase()
        {
            Items = new ObservableCollection<T>();
            delayedNotifications = new List<Action>();
        }

        private System.Collections.ObjectModel.ObservableCollection<T> items;
        protected System.Collections.ObjectModel.ObservableCollection<T> Items
        {
            get
            {
                return items;
            }
            set
            {
                if (items != value)
                {
                    if (items != null)
                        DeregisterItems();
                    items = value;
                    if (items != null)
                        RegisterItems();
                    RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
                    RaisePropertyChanged("Item[]");
                    RaisePropertyChanged("Count");
                }
            }
        }

        private void RegisterItems()
        {
            items.CollectionChanged += items_CollectionChanged;
            ((INotifyPropertyChanged)items).PropertyChanged += items_PropertyChanged;
        }

        private void items_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            RaisePropertyChanged(e.PropertyName);
        }

        private void items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            RaiseCollectionChanged(e);
        }

        private void DeregisterItems()
        {
            items.CollectionChanged -= items_CollectionChanged;
            ((INotifyPropertyChanged)items).PropertyChanged -= items_PropertyChanged;
        }

        protected void RaiseCollectionChanged(NotifyCollectionChangedEventArgs args)
        {
            if (SuppressChangeNotifications > 0)
                return;
            if (DelayChangeNotifications)
            {
                delayedNotifications.Add(() => RaiseCollectionChanged(args));
                return;
            }
            var cc = collectionChanged;
            if (cc != null)
                cc(this, args);
        }

        protected void RaisePropertyChanged(string propertyName)
        {
            if (SuppressChangeNotifications > 0)
                return;
            if (DelayChangeNotifications)
            {
                delayedNotifications.Add(() => RaisePropertyChanged(propertyName));
                return;
            }
            var pc = propertyChanged;
            if (pc != null)
                pc(this, new PropertyChangedEventArgs(propertyName));
        }

        protected int ListenerCount { get; private set; }
        protected int SuppressChangeNotifications { get; set; }
        private List<Action> delayedNotifications;
        private bool delayChangeNotifications;
        protected bool DelayChangeNotifications
        {
            get
            {
                return delayChangeNotifications;
            }
            set
            {
                if (delayChangeNotifications != value)
                {
                    delayChangeNotifications = value;
                    if (!delayChangeNotifications)
                    {
                        foreach (Action notification in delayedNotifications)
                            notification();
                        delayedNotifications.Clear();
                    }
                }
            }
        }

        protected virtual void ListenerAdded()
        {
        }

        protected virtual void ListenerRemoved()
        {
        }

        private NotifyCollectionChangedEventHandler collectionChanged;
        public event NotifyCollectionChangedEventHandler CollectionChanged
        {
            add
            {
                collectionChanged += value;
                ListenerCount++;
                ListenerAdded();
            }
            remove
            {
                collectionChanged -= value;
                ListenerCount--;
                ListenerRemoved();
            }
        }

        private PropertyChangedEventHandler propertyChanged;
        event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
        {
            add
            {
                propertyChanged += value;
                ListenerCount++;
                ListenerAdded();
            }
            remove
            {
                propertyChanged -= value;
                ListenerCount--;
                ListenerRemoved();
            }
        }

        public virtual IEnumerator<T> GetEnumerator()
        {
            if (items == null)
                return new List<T>().GetEnumerator();
            return items.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public void CopyTo(Array array, int index)
        {
            if (items == null)
                ((ICollection)new ObservableCollection<T>()).CopyTo(array, index);
            else
                ((ICollection)items).CopyTo(array, index);

        }

        public int Count
        {
            get { return items == null ? 0 : items.Count; }
        }

        public bool IsSynchronized
        {
            get { return items == null ? false : ((ICollection)items).IsSynchronized; }
        }

        private object syncRoot = new object();
        public object SyncRoot
        {
            get { return syncRoot; }
        }
    }
}
