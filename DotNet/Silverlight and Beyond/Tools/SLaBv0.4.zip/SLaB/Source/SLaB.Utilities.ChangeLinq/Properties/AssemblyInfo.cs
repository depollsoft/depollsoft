﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Markup;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SLaB.Utilities.ChangeLinq")]

[assembly: XmlnsDefinition(Constants.XmlNamespace, "SLaB.Utilities.ChangeLinq")]
