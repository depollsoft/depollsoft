﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;

namespace SLaB.Utilities.ChangeLinq
{
    internal class SelectObservableCollection<TIn, TOut> : ChangeLinqBase<TOut>
    {
        private IEnumerable<TIn> original;
        protected IEnumerable<TIn> Original
        {
            get
            {
                return original;
            }
            set
            {
                if (ListenerCount > 0)
                    DetachFromSource();
                if (value == null)
                    this.original = new TIn[0];
                else if (!(value is INotifyCollectionChanged))
                    this.original = value.ToArray();
                else
                    this.original = value;
                if (ListenerCount > 0)
                    AttachToSource();
            }
        }
        private Func<TIn, TOut> selector;
        public SelectObservableCollection(IEnumerable<TIn> original, Func<TIn, TOut> selector)
        {
            this.selector = selector;
            this.Original = original;
        }

        protected override void AttachToSource()
        {
            if (original is INotifyCollectionChanged)
                ((INotifyCollectionChanged)original).CollectionChanged += SelectObservableCollection_CollectionChanged;
            SuppressChangeNotifications++;
            Reset();
            SuppressChangeNotifications--;
        }
        protected override void DetachFromSource()
        {
            if (original is INotifyCollectionChanged)
                ((INotifyCollectionChanged)original).CollectionChanged -= SelectObservableCollection_CollectionChanged;
        }

        private void SelectObservableCollection_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            DelayChangeNotifications = true;
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    var added = from item in e.NewItems.Cast<TIn>()
                                select selector(item);
                    foreach (var item in added.Reverse())
                        this.Items.Insert(e.NewStartingIndex, item);
                    break;
                case NotifyCollectionChangedAction.Remove:
                    foreach (var item in e.OldItems)
                        this.Items.RemoveAt(e.OldStartingIndex);
                    break;
                case NotifyCollectionChangedAction.Replace:
                    var newItems = (from item in e.NewItems.Cast<TIn>()
                                    select selector(item)).ToArray();
                    for (int x = 0; x < e.OldItems.Count; x++)
                        this.Items[e.NewStartingIndex + x] = newItems[x];
                    break;
                case NotifyCollectionChangedAction.Reset:
                    Reset();
                    break;
            }
            DelayChangeNotifications = false;
        }

        private void Reset()
        {
            this.SuppressChangeNotifications++;
            this.Items.Clear();
            foreach (var item in this.original)
                this.Items.Add(selector(item));
            this.SuppressChangeNotifications--;
            RaisePropertyChanged("Count");
            RaisePropertyChanged("Item[]");
            RaiseCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        public override void Refresh()
        {
            if (original is IRefreshable)
                ((IRefreshable)original).Refresh();
            Reset();
        }
    }
}
