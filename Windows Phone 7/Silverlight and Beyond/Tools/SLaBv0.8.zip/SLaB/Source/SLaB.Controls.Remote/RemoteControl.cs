﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using SLaB.Utilities;
using SLaB.Utilities.Xap;
using System.Threading;

namespace SLaB.Controls.Remote
{
    /// <summary>
    /// A control that downloads a Xap and its dependencies, then displays some content given a class name to instantiate.
    /// </summary>
    [TemplateVisualState(GroupName = RemoteControl.RemoteContentLoadingStatusGroup, Name = RemoteControl.RemoteContentLoadingState)]
    [TemplateVisualState(GroupName = RemoteControl.RemoteContentLoadingStatusGroup, Name = RemoteControl.RemoteContentLoadedState)]
    [StyleTypedProperty(Property = "ProgressStyle", StyleTargetType = typeof(ProgressBar))]
    [ContentProperty("Setters")]
    [DefaultEvent("RemoteContentLoaded")]
    public class RemoteControl : Control, ISupportInitialize
    {
        /// <summary>
        /// The name of the state group for remote content loading.
        /// </summary>
        public const string RemoteContentLoadingStatusGroup = "RemoteContentStatus";
        /// <summary>
        /// The name of the RemoteContentLoading state.
        /// </summary>
        public const string RemoteContentLoadingState = "RemoteContentLoading";
        /// <summary>
        /// The name of the RemoteContentLoaded state.
        /// </summary>
        public const string RemoteContentLoadedState = "RemoteContentLoaded";
        private bool isSettingContent;
        private bool isSettingProgress;

        /// <summary>
        /// Constructs a RemoteControl.
        /// </summary>
        public RemoteControl()
        {
            this.DefaultStyleKey = typeof(RemoteControl);
        }

        /// <summary>
        /// An event raised when remote content has finished loading.
        /// </summary>
        public event EventHandler<EventArgs> RemoteContentLoaded;

        /// <summary>
        /// Causes the control to load its content from the remote Xap.  Automatically called upon EndInit() for usages that
        /// recognize/use ISupportInitialize, such as the XAML parser.
        /// </summary>
        public void Load()
        {
            Dispatcher.BeginInvoke(() =>
                {
                    if (Content == null && !DesignerProperties.IsInDesignTool)
                    {
                        VisualStateManager.GoToState(this, RemoteContentLoadingState, true);
                        if (ClassName == null || AssemblyName == null || XapLocation == null)
                            throw new ArgumentNullException("ClassName, AssemblyName, and XapLocation must not be null.");
                        XapLoader loader = new XapLoader();
                        XapLoader.XapAsyncResult result = (XapLoader.XapAsyncResult)loader.BeginLoadXap(this.XapLocation, (r) =>
                        {
                            Dispatcher.BeginInvoke(() => LoadFromXap(loader.EndLoadXap(r)));
                        }, null);
                        result.PropertyChanged += (sender, args) =>
                        {
                            if (args.PropertyName.Equals("Progress"))
                                UiUtilities.ExecuteOnUiThread(() => Progress = result.Progress);
                        };
                    }
                });
        }

        /// <summary>
        /// Called when the component is being initialized.
        /// </summary>
        void ISupportInitialize.BeginInit()
        {
        }

        /// <summary>
        /// Called when initialization has ended.  Automatically calls the Load() method.
        /// </summary>
        void ISupportInitialize.EndInit()
        {
            Load();
        }

        private void LoadFromXap(Xap xap)
        {
            var foundAssembly = (from asm in xap.Assemblies
                                 where System.Reflection.AssemblyName.ReferenceMatchesDefinition(new System.Reflection.AssemblyName(asm.FullName), new System.Reflection.AssemblyName(AssemblyName))
                                 select asm).Single();
            Type t = foundAssembly.GetType(ClassName, true);
            string rdLocation = string.Format("/{0};component/Resources.xaml", new AssemblyName(foundAssembly.FullName).Name);
            try { Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri(rdLocation, UriKind.Relative) }); }
            catch { }
            Content = Activator.CreateInstance(t);
            VisualStateManager.GoToState(this, RemoteContentLoadedState, true);
            RemoteContentLoaded.Raise(this, new EventArgs());
        }

        /// <summary>
        /// Gets or sets the full name of the class to load.
        /// </summary>
        [Category("Common Properties")]
        public string ClassName { get; set; }
        /// <summary>
        /// Gets or sets the name of the assembly in which the class to be loaded can be found.
        /// </summary>
        [Category("Common Properties")]
        public string AssemblyName { get; set; }
        /// <summary>
        /// Gets or sets the Uri for the Xap from which the class will be loaded.
        /// </summary>
        [Category("Common Properties")]
        public Uri XapLocation { get; set; }

        /// <summary>
        /// Gets the progress of the Xap download.
        /// </summary>
        public double Progress
        {
            get { return (double)GetValue(ProgressProperty); }
            private set
            {
                isSettingProgress = true;
                SetValue(ProgressProperty, value);
                isSettingProgress = false;
            }
        }

        /// <summary>
        /// Gets the progress of the Xap download.
        /// </summary>
        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(double), typeof(RemoteControl), new PropertyMetadata(default(double), OnProgressChanged));

        private static void OnProgressChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((RemoteControl)obj).OnProgressChanged((double)args.OldValue, (double)args.NewValue);
        }

        private void OnProgressChanged(double oldValue, double newValue)
        {
            if (!isSettingProgress)
            {
                Progress = oldValue;
                throw new AccessViolationException("Cannot set the Progress property");
            }
        }

        /// <summary>
        /// Gets or sets the DataTemplate for the content if necessary.
        /// </summary>
        public DataTemplate ContentTemplate
        {
            get { return (DataTemplate)GetValue(ContentTemplateProperty); }
            set { SetValue(ContentTemplateProperty, value); }
        }

        /// <summary>
        /// Gets or sets the DataTemplate for the content if necessary.
        /// </summary>
        public static readonly DependencyProperty ContentTemplateProperty =
            DependencyProperty.Register("ContentTemplate", typeof(DataTemplate), typeof(RemoteControl), new PropertyMetadata(default(DataTemplate)));

        /// <summary>
        /// Gets the loaded content.  Null if the content has not yet been loaded.
        /// </summary>
        public object Content
        {
            get { return (object)GetValue(ContentProperty); }
            private set
            {
                isSettingContent = true;
                SetValue(ContentProperty, value);
                isSettingContent = false;
            }
        }

        /// <summary>
        /// Gets the loaded content.  Null if the content has not yet been loaded.
        /// </summary>
        public static readonly DependencyProperty ContentProperty =
            DependencyProperty.Register("Content", typeof(object), typeof(RemoteControl), new PropertyMetadata(default(object), OnContentChanged));

        private static void OnContentChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((RemoteControl)obj).OnContentChanged((object)args.OldValue, (object)args.NewValue);
        }

        private void OnContentChanged(object oldValue, object newValue)
        {
            if (!isSettingContent)
            {
                Content = oldValue;
                throw new AccessViolationException("Cannot set the Content property");
            }
        }

        /// <summary>
        /// Gets or sets the style for the progress bar that is displayed before the content has been loaded.
        /// </summary>
        public Style ProgressStyle
        {
            get { return (Style)GetValue(ProgressStyleProperty); }
            set { SetValue(ProgressStyleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the style for the progress bar that is displayed before the content has been loaded.
        /// </summary>
        public static readonly DependencyProperty ProgressStyleProperty =
            DependencyProperty.Register("ProgressStyle", typeof(Style), typeof(RemoteControl), new PropertyMetadata(default(Style)));
    }
}
