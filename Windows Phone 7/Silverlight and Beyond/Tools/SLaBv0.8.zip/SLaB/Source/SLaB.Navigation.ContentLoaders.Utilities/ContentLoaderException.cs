﻿using System;

namespace SLaB.Navigation.ContentLoaders.Utilities
{
    /// <summary>
    /// Represents an exception thrown by a ContentLoaderBase
    /// </summary>
    public class ContentLoaderException : Exception
    {
        /// <summary>
        /// Constructs a ContentLoaderException.
        /// </summary>
        /// <param name="throwingType">The type of ContentLoader that had an error.</param>
        /// <param name="cause">The cause of the error.</param>
        public ContentLoaderException(Type throwingType, Exception cause)
            : base(string.Format("{0} failed to load content.", throwingType), cause)
        {
        }
    }
}
