﻿using System;
using System.Text.RegularExpressions;

namespace SLaB.Navigation.ContentLoaders.Xap
{
    internal class PackUriHelper
    {
        public static readonly Uri Application;
        public static readonly Uri PackApplication;
        public static readonly Uri SiteOfOriginReal;
        public static readonly Uri SiteOfOrigin;
        private static readonly Regex componentRegex = new Regex(@"^(?<packassemblyname>/(?<assemblyname>.*?)(;v(?<version>.*?))?(;(?<publickey>.*?))?;component)?(?<path>/.*?)(\?.*?)?(#.*?)?$");
        private static readonly Regex assemblyNameRegex = new Regex(@"^(?<name>.*?)(,\s*version=(?<version>.*?))?(,\s*culture=(?<culture>.*?))?(,\s*PublicKeyToken=(?<publickey>.*?))?$", RegexOptions.IgnoreCase);

        static PackUriHelper()
        {
            PackUriParser.Initialize();
            Application = new Uri("application:///");
            PackApplication = new Uri("pack://application:,,,");
            SiteOfOrigin = new Uri("siteoforigin:///");
            Uri sorBase = new Uri(System.Windows.Application.Current.Host.Source, ".");
            string full = Uri.EscapeDataString(sorBase.OriginalString).Replace("%2F", ",").Replace("%2f", ",").Replace("%3A", ":").Replace("%3a", ":");
            SiteOfOriginReal = new Uri("pack://" + full);
        }

        private Uri uri;
        public PackUriHelper(Uri uri)
        {
            if (!uri.IsAbsoluteUri)
                uri = new Uri(PackApplication, uri);
            if (!uri.Scheme.Equals("pack"))
                throw new ArgumentException("Uri is not a pack uri");
            this.uri = uri;
        }

        public Uri Uri
        {
            get
            {
                return uri;
            }
        }

        public Uri RealAuthority
        {
            get
            {
                return new Uri(Uri.UnescapeDataString(uri.Host.Replace(",", "/")));
            }
        }

        public Uri Authority
        {
            get
            {
                if (RealAuthority.Scheme.Equals("siteoforigin"))
                {
                    return new Uri(System.Windows.Application.Current.Host.Source, RealAuthority.OriginalString.Substring("siteoforigin://".Length));
                }
                else if (RealAuthority.Scheme.Equals("application"))
                {
                    return System.Windows.Application.Current.Host.Source;
                }
                return RealAuthority;
            }
        }

        public string AssemblyName
        {
            get
            {
                Match m = componentRegex.Match(uri.AbsolutePath);
                if (!m.Groups["assemblyname"].Success)
                    return null;
                string name = m.Groups["assemblyname"].Value;
                if (m.Groups["version"].Success)
                    name += ",Version=" + m.Groups["version"].Value;
                if (m.Groups["publickey"].Success)
                    name += ",PublicKeyToken=" + m.Groups["publickey"].Value;
                return name;
            }
        }

        public string PackAssemblyName
        {
            get
            {
                Match m = componentRegex.Match(uri.AbsolutePath);
                if (!m.Groups["packassemblyname"].Success)
                    return null;
                string name = m.Groups["packassemblyname"].Value;
                return name;
            }
        }

        public string Path
        {
            get
            {
                Match m = componentRegex.Match(uri.AbsolutePath);
                return m.Groups["path"].Value;
            }
        }

        public string RelativePath
        {
            get
            {
                return uri.OriginalString.Substring("pack://".Length + uri.Host.Length + 1);
            }
        }

        public static Uri BuildPackUri(Uri authority, string path, string assemblyName = null)
        {
            string translatedAuthority = Uri.EscapeDataString(authority.OriginalString).Replace("%2F", ",").Replace("%2f", ",").Replace("%3A", ":").Replace("%3a", ":");
            if (string.IsNullOrWhiteSpace(assemblyName))
                return new Uri(string.Format("pack://{0}{1}", translatedAuthority, path));
            Match anParts = assemblyNameRegex.Match(assemblyName);
            string translatedAssemblyName = anParts.Groups["name"].Value;
            if (anParts.Groups["version"].Success)
                translatedAssemblyName += ";v" + anParts.Groups["version"].Value;
            if (anParts.Groups["publickey"].Success)
                translatedAssemblyName += ";" + anParts.Groups["publickey"].Value;
            if (!path.StartsWith("/"))
                path = "/" + path;
            return new Uri(string.Format("pack://{0}/{1};component{2}", translatedAuthority, translatedAssemblyName, path));
        }
    }
}
