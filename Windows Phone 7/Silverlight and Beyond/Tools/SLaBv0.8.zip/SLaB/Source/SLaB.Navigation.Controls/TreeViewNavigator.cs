﻿using System.Windows;
using System.Windows.Controls;
using SLaB.Navigation.Controls.Sitemap;
using SLaB.Utilities.Xaml;
using SLaB.Utilities.Xaml.Converters;

namespace SLaB.Navigation.Controls
{
    /// <summary>
    /// A control for TreeView-based navigation within a Silverlight application.
    /// </summary>
    [StyleTypedProperty(Property = "ItemContainerStyle", StyleTargetType = typeof(TreeViewItem))]
    [StyleTypedProperty(Property = "TreeViewStyle", StyleTargetType = typeof(TreeView))]
    [TemplatePart(Name = "TreeView", Type = typeof(TreeView))]
    [XamlDependency(typeof(BoolConverter))]
    [XamlDependency(typeof(CollectionConverter))]
    [XamlDependency(typeof(WrappingConverter))]
    [XamlDependency(typeof(TreeView))]
    [XamlDependency(typeof(HierarchicalDataTemplate))]
    public class TreeViewNavigator : Navigator
    {
        private TreeView treeview;

        /// <summary>
        /// Creates a TreeViewNavigator.
        /// </summary>
        public TreeViewNavigator()
        {
            this.DefaultStyleKey = typeof(TreeViewNavigator);
        }

        /// <summary>
        /// Called when a template is applied.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            treeview = (TreeView)GetTemplateChild("TreeView");
            RefreshExpansion();
        }

        /// <summary>
        /// Called when CurrentSource changes.
        /// </summary>
        protected override void OnCurrentSourceChanged()
        {
            RefreshExpansion();
        }

        private void RefreshExpansion()
        {
            if (ExpandAll && treeview != null)
            {
                foreach (SitemapNodeProxy item in treeview.Items)
                {
                    Expand(item);
                }
            }
        }

        private void Expand(SitemapNodeProxy item)
        {
            item.IsInPath = true;
            foreach (SitemapNodeProxy child in item.Nodes)
                Expand(child);
        }

        /// <summary>
        /// Gets or sets whether all items in the TreeView should be expanded.
        /// </summary>
        public bool ExpandAll
        {
            get { return (bool)GetValue(ExpandAllProperty); }
            set { SetValue(ExpandAllProperty, value); }
        }

        /// <summary>
        /// Gets or sets whether all items in the TreeView should be expanded.
        /// </summary>
        public static readonly DependencyProperty ExpandAllProperty =
            DependencyProperty.Register("ExpandAll", typeof(bool), typeof(TreeViewNavigator), new PropertyMetadata(false, OnExpandAllChanged));

        private static void OnExpandAllChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ((TreeViewNavigator)obj).OnExpandAllChanged();
        }

        private void OnExpandAllChanged()
        {
            RefreshExpansion();
        }

        /// <summary>
        /// Gets or sets the style for the ItemContainer that will be used in the TreeView.
        /// </summary>
        public Style ItemContainerStyle
        {
            get { return (Style)GetValue(ItemContainerStyleProperty); }
            set { SetValue(ItemContainerStyleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the style for the ItemContainer that will be used in the TreeView.
        /// </summary>
        public static readonly DependencyProperty ItemContainerStyleProperty =
            DependencyProperty.Register("ItemContainerStyle", typeof(Style), typeof(TreeViewNavigator), new PropertyMetadata(null));


        /// <summary>
        /// Gets or sets the style for the TreeView.
        /// </summary>
        public Style TreeViewStyle
        {
            get { return (Style)GetValue(TreeViewStyleProperty); }
            set { SetValue(TreeViewStyleProperty, value); }
        }

        /// <summary>
        /// Gets or sets the style for the TreeView.
        /// </summary>
        public static readonly DependencyProperty TreeViewStyleProperty =
            DependencyProperty.Register("TreeViewStyle", typeof(Style), typeof(TreeViewNavigator), new PropertyMetadata(null));
    }
}
