﻿using System.Windows;

namespace SLaB.Utilities.Xap.Deployment
{
    /// <summary>
    /// Represents a collection of SLaB.Utilities.Xap.Deployment.Icon instances.
    /// </summary>
    public class IconCollection : DependencyObjectCollection<Icon>
    {

    }
}
