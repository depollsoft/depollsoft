﻿using System.Windows;
using SLaB.Controls.Remote;

namespace ScratchApplication
{
    public partial class App : Application
    {
        public App()
        {
            this.Startup += this.Application_Startup;
            InitializeComponent();
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var rc = new RemoteControl
            {
                ClassName = "ScratchContent.MainPage",
                AssemblyName = "ScratchContent",
                XapLocation = new System.Uri("ScratchContent.xap", System.UriKind.Relative)
            };
            RootVisual = rc;
            rc.Load();
            Application.Current.CheckAndDownloadUpdateCompleted += Current_CheckAndDownloadUpdateCompleted;
            Application.Current.CheckAndDownloadUpdateAsync();
        }

        private void Current_CheckAndDownloadUpdateCompleted(object sender, CheckAndDownloadUpdateCompletedEventArgs e)
        {
            if (e.UpdateAvailable)
            {
                if (MessageBox.Show("The application has been updated and needs to be restarted.  Click OK to restart the application now, or cancel to continue using the application.", "Application updated", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                    Application.Current.MainWindow.Close();
            }
        }
    }
}