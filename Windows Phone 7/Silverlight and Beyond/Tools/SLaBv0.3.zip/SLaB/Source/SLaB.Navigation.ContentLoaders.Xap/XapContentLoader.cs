﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Navigation;
using SLaB.Navigation.ContentLoaders.Utilities;
using SLaB.Utilities.Xap;
using xap = SLaB.Utilities.Xap;

namespace SLaB.Navigation.ContentLoaders.Xap
{
    /// <summary>
    /// An INavigationContentLoader that loads pages in Xaps specified by a pack Uri.  This loader will download the Xap if it has not already been downloaded
    /// and then load a page within that Xap, making it easy to build multi-Xap applications using Navigation.
    /// </summary>
    public class XapContentLoader : ContentLoaderBase
    {
        static XapContentLoader()
        {
            PackUriParser.Initialize();
        }

        private Dictionary<Uri, xap.Xap> foundXaps;
        /// <summary>
        /// Constructs a XapContentLoader.
        /// </summary>
        public XapContentLoader()
        {
            foundXaps = new Dictionary<Uri, xap.Xap>();
        }

        /// <summary>
        /// Creates an instance of a LoaderBase that will be used to handle loading.
        /// </summary>
        /// <returns>An instance of a LoaderBase.</returns>
        protected override LoaderBase CreateLoader()
        {
            return new Loader(this);
        }

        /// <summary>
        /// Gets the progress of any ongoing downloads that the XapContentLoader is performing.
        /// </summary>
        public double Progress
        {
            get { return (double)GetValue(ProgressProperty); }
            private set { SetValue(ProgressProperty, value); }
        }

        /// <summary>
        /// Gets the progress of any ongoing downloads that the XapContentLoader is performing.
        /// </summary>
        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(double), typeof(XapContentLoader), new PropertyMetadata(0d));

        /// <summary>
        /// Gets a boolean indicating whether the XapContentLoader is in the process of downloading or loading a page.
        /// </summary>
        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            private set { SetValue(IsBusyProperty, value); }
        }

        /// <summary>
        /// Gets a boolean indicating whether the XapContentLoader is in the process of downloading or loading a page.
        /// </summary>
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(XapContentLoader), new PropertyMetadata(false));

        /// <summary>
        /// Gets or sets whether the XapContentLoader is allowed to download Xaps from a domain other than the domain of origin for the application.
        /// This feature is disabled by default, but can be enabled to load arbitrary Xaps.  If you enable this feature, please limit access to other domains
        /// using some other mechanism.
        /// </summary>
        public bool EnableCrossDomain
        {
            get { return (bool)GetValue(EnableCrossDomainProperty); }
            set { SetValue(EnableCrossDomainProperty, value); }
        }

        /// <summary>
        /// Gets or sets whether the XapContentLoader is allowed to download Xaps from a domain other than the domain of origin for the application.
        /// This feature is disabled by default, but can be enabled to load arbitrary Xaps.  If you enable this feature, please limit access to other domains
        /// using some other mechanism.
        /// </summary>
        public static readonly DependencyProperty EnableCrossDomainProperty =
            DependencyProperty.Register("EnableCrossDomain", typeof(bool), typeof(XapContentLoader), new PropertyMetadata(false));

        /// <summary>
        /// Gets a value that indicates whether the specified URI can be loaded.
        /// </summary>
        /// <param name="targetUri">The URI to test.</param>
        /// <param name="currentUri">The URI that is currently loaded.</param>
        /// <returns>true if the URI can be loaded; otherwise, false.</returns>
        public override bool CanLoad(Uri targetUri, Uri currentUri)
        {
            try
            {
                PackUriHelper helper = new PackUriHelper(targetUri);
                if (EnableCrossDomain)
                    return true;
                return helper.Authority.Host.Equals(Application.Current.Host.Source.Host);
            }
            catch
            {
                return false;
            }
        }

        private class Loader : LoaderBase
        {
            private XapContentLoader loader;
            private IAsyncResult result;
            private INavigationContentLoader currentLoader;
            private XapLoader xapLoader;
            public Loader(XapContentLoader loader)
            {
                this.loader = loader;
            }
            public override void Load(Uri targetUri, Uri currentUri)
            {
                if (!loader.CanLoad(targetUri, currentUri))
                    throw new UnauthorizedAccessException("Cannot load uri due to cross-domain limitations");
                loader.Progress = 0;
                loader.IsBusy = true;
                PackUriHelper helper = new PackUriHelper(targetUri);
                Uri authority = helper.Authority;
                if (helper.Authority.Equals(PackUriHelper.Application))
                    authority = Application.Current.Host.Source;
                if (loader.foundXaps.ContainsKey(authority))
                {
                    FinishLoading(loader.foundXaps[authority], helper, currentUri);
                    return;
                }
                xapLoader = new XapLoader();
                this.result = xapLoader.BeginLoadXap(authority, (res) =>
                {
                    try
                    {
                        xap.Xap resultingXap = xapLoader.EndLoadXap(res);
                        loader.foundXaps[authority] = resultingXap;
                        FinishLoading(loader.foundXaps[authority], helper, currentUri);
                    }
                    catch (Exception e)
                    {
                        loader.IsBusy = false;
                        Error(e);
                        return;
                    }
                }, null);
                xap.XapLoader.XapAsyncResult result = (xap.XapLoader.XapAsyncResult)this.result;
                result.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(result_PropertyChanged);
            }


            void result_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
            {
                xap.XapLoader.XapAsyncResult result = (xap.XapLoader.XapAsyncResult)sender;
                loader.Progress = result.Progress;
            }

            private void FinishLoading(xap.Xap finalXap, PackUriHelper uri, Uri currentUri)
            {
                INavigationContentLoader finalLoader = new XapPageResourceContentLoader() { Xap = finalXap };
                currentLoader = finalLoader;
                try
                {
                    this.result = finalLoader.BeginLoad(new Uri(uri.RelativePath, UriKind.Relative), currentUri, (res) =>
                        {
                            try
                            {
                                LoadResult result = finalLoader.EndLoad(res);
                                if (result.RedirectUri != null)
                                {
                                    loader.IsBusy = false;
                                    Complete(result.RedirectUri);
                                    return;
                                }
                                else
                                {
                                    loader.IsBusy = false;
                                    Complete(result.LoadedContent);
                                    return;
                                }
                            }
                            catch (Exception e)
                            {
                                loader.IsBusy = false;
                                Error(e);
                                return;
                            }
                        }, null);
                }
                catch (Exception ex)
                {
                    loader.IsBusy = false;
                    Error(ex);
                    return;
                }
            }

            public override void Cancel()
            {
                loader.IsBusy = false;
                if (result is xap.XapLoader.XapAsyncResult)
                    xapLoader.CancelLoadXap(result);
                else
                    currentLoader.CancelLoad(result);
            }
        }
    }
}
