﻿using System;

namespace SLaB.Navigation.Utilities
{
    /// <summary>
    /// A mapping for use by a UriMapper.  Maps an input Uri to an output Uri.
    /// </summary>
    public interface IUriMapping
    {
        Uri MapUri(Uri uri);
    }
}
