//
//  Accidental.h
//  pitchperfectlib
//
//  Created by David Poll on 3/24/12.
//  Copyright (c) 2012 DepollSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DPEnum.h"

enum Accidental {
    Flat,
    Natural,
    Sharp
};

@interface DPAccidental : DPEnum {
    
}

@end
