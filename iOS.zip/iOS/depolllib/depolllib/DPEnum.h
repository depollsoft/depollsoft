//
//  DPEnum.h
//  depolllib
//
//  Created by David Poll on 4/29/12.
//  Copyright (c) 2012 DepollSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DPEnum : NSObject

- (id)initWithString:(NSString *)string;
- (id)initWithValue:(NSNumber *)value;
- (id)initWithInt:(int)value;
- (NSString *)name;
+ (NSDictionary *)getEnumValues;

@property (readonly) NSNumber *value;

@end
